# Open reading source attribution

These are separate complete paragraphs, with whitespace normalised, from the fixed editions below. CC BY 4.0 applies to the licensed original prose only. No source media, table, exercise, footnote, borrowed quotation container or excluded third-party content is included. All records remain draft; this is not CEFR calibration.

- Psychology 2e: Rose M. Spielman; William J. Jenkins; Marilyn D. Lovett. OpenStax, Rice University. Source: https://github.com/openstax/osbooks-psychology/blob/e061043bf2f9e86ace51c4e8dc9555160f60a99d/collections/psychology-2e.collection.xml. Archive/home SHA256: 6be60580c7d640091e5406bf3c28ca9c5aa84b8de717cd5110ce11ba104c5435.
- Biology 2e: Mary Ann Clark; Jung Choi; Matthew Douglas. OpenStax, Rice University. Source: https://github.com/openstax/osbooks-biology-bundle/blob/d2779c2edfb435e75047325434fe2fe93d5aa120/collections/biology-2e.collection.xml. Archive/home SHA256: ad36c39c255b4b369765e8d7db8f0f41cc23074555e07649e13cf295ca79253e.
- Physical Geology - 2nd Edition: Steven Earle; Karla Panchuk. BCcampus. Source: https://opentextbc.ca/physicalgeology2ed/. Archive/home SHA256: bac292c654f85b96e17831f8db7b5ce9181e0d062f0f3a133aefc298a7fd4f71.
- Introduction to Sociology 3e: Tonja R. Conerly; Kathleen Holmes; Asha Lal Tamang. OpenStax, Rice University. Source: https://github.com/openstax/osbooks-introduction-sociology/blob/d35d5f3bdac40f93607d600134865d4f13ce1f9b/collections/introduction-sociology-3e.collection.xml. Archive/home SHA256: 93918f53e902eeab76e526924bf6807e3b3f04e1127f4bdb03b7b2b2d87d2a0b.
- U.S. History: P. Scott Corbett; Jay Precht; Volker Janssen; John M. Lund; Todd Pfannestiel; Paul Vickery; Sylvie Waskiewicz. OpenStax, Rice University. Source: https://github.com/openstax/osbooks-us-history/blob/046331cfcea0ac1b1a8fd461b3e6aae638845af3/collections/us-history.collection.xml. Archive/home SHA256: 522791e9ee96f31b4146759bdf6c54377222d1356816108431270d94f02b0dbb.

Physical Geology copyright 2019 Steven Earle, chapter 22 Karla Panchuk. Original exception policy: https://opentextbc.ca/physicalgeology2ed/front-matter/exceptions-to-the-cc-by-licence/ . All listed media exceptions are excluded.

Licence: https://creativecommons.org/licenses/by/4.0/ ; the complete unchanged legal code accompanies this package. OpenStax current-main editions are not admitted by these old-edition grants. Retain author/institution/source attribution and indicate changes on reuse. No endorsement is implied.

BC Reads: Adult Literacy Fundamental English – Reader 1 by Shantel Ivits, BCcampus (2015). CC BY 4.0. Download for free from the B.C. Open Collection: https://opentextbc.ca/abealfreader1/
Introduction to Business — Lawrence J. Gitman; Carl McDaniel; Amit Shah; Monique Reece; Linda Koffel; Bethann Talsma; James C. Hyatt. OpenStax, Rice University. Frozen 9d3b8c44e4567d207424bc92d4f7ceffb1a9dcd5 source edition, CC BY 4.0; complete native paragraphs, whitespace normalised; third-party/media excluded.
Organizational Behavior — J. Stewart Black; David S. Bright; Donald G. Gardner; Eva Hartmann; Jason Lambert; Laura M. Leduc; Joy Leopold; James S. O’Rourke; Jon L. Pierce; Richard M. Steers; Siri Terjesen; Joseph Weiss. OpenStax, Rice University. Frozen 54660e7c5d6b4495a796032457a70a94708f3eeb source edition, CC BY 4.0; complete native paragraphs, whitespace normalised; third-party/media excluded.
Principles of Management — David S. Bright; Anastasia H. Cortes; Eva Hartmann; K. Praveen Parboteeah; Jon L. Pierce; Monique Reece; Amit Shah; Siri Terjesen; Joseph Weiss; Margaret A. White; Donald G. Gardner; Jason Lambert; Laura M. Leduc; Joy Leopold; Jeffrey Muldoon; James S. O’Rourke. OpenStax, Rice University. Frozen 54660e7c5d6b4495a796032457a70a94708f3eeb source edition, CC BY 4.0; complete native paragraphs, whitespace normalised; third-party/media excluded.
Principles of Marketing — Maria Gomez Albrecht; Mark Green; Linda Hoffman; Jacqueline Babb; Lauren M. Donovan; Debra Ellerbrook; Lisa S. Goolsby; Jaciel Keltgen; Sarah M. Shepler; Deborah Toomey. OpenStax, Rice University. Frozen deb6e19777dc40f3c8861fad1a3fa319d91a940a source edition, CC BY 4.0; complete native paragraphs, whitespace normalised; third-party/media excluded.
Introduction to Anthropology — Jennifer Hasty; David G. Lewis; Marjorie M. Snipes; Todd A. Barnhardt; M. Anne Basham; Sharon Gursky; Laura Jarvis-Seibert; Saira A. Mehmood; Sydney Yeager. OpenStax, Rice University. CC BY 4.0 frozen source edition; complete native paragraphs, whitespace normalised; third-party/media excluded.
Introduction to Philosophy — Nathan Smith; Gregory Browne; Parish Conkling; Naomi Friedman; Allison Fritz; Daniel Garro; Jeremy Gallegos; Jon Gill; Gayle Horton; Maryellen Lo Bosco; Rebecca A. Longtin; Corey McCall; Kurt Stuke. OpenStax, Rice University. Frozen ec2804507cf93609bcdd72cc2f2f5aea054a8ae5 source edition, CC BY 4.0; complete native paragraphs, whitespace normalised; third-party/media excluded.
World History Volume 1, to 1500 — Ann Kordas; Ryan J. Lynch; Brooke Nelson; Julie Tatlock; Chris Bingley; Celeste Chamberland; Scott Corbett; Rick Gianni; Jennifer Lawrence; Jamie McCandless; Cristina Mehrtens; Anthony Miller; Abigail Owen; David Price; Kim Richardson; Christopher S Rose; Joseph Snyder; Christopher Thrasher; David Toye; Alexander Wathen; Grace Hunt Watkinson; Joel Webb. OpenStax, Rice University. Frozen dbe4cb6de157b506f07fab8c52ffe80704578f69 source edition, CC BY 4.0; complete native paragraphs, whitespace normalised; third-party/media excluded.
World History Volume 2, from 1400 — Ann Kordas; Ryan J. Lynch; Brooke Nelson; Julie Tatlock; Chris Bingley; Celeste Chamberland; Scott Corbett; Rick Gianni; Jennifer Lawrence; Jamie McCandless; Cristina Mehrtens; Anthony Miller; Abigail Owen; David Price; Kim Richardson; Christopher S Rose; Joseph Snyder; Christopher Thrasher; David Toye; Alexander Wathen; Grace Hunt Watkinson; Joel Webb. OpenStax, Rice University. Frozen dbe4cb6de157b506f07fab8c52ffe80704578f69 source edition, CC BY 4.0; complete native paragraphs, whitespace normalised; third-party/media excluded.
Introduction to Political Science — Mark Carl Rom; Masaki Hidaka; Rachel Bzostek Walker; Emilia B. Carvalho; Rebecca Eissler; Terri Susan Fine; Cassandra Khatri; Timothy Lim; Brenda Norton; Robert Postic; Joseph Prud’homme; Shyam Krishnan Sriram; Victoria Williams. OpenStax, Rice University. CC BY 4.0 frozen source edition; complete native paragraphs, whitespace normalised; third-party/media excluded.
College Success — Amy Baldwin; Lisa August; James Bennett; Larry Buland; Sabrina Mathues; Susan Monroe; MJ O’Leary; Ann Pearson; Joshua Troesh; Margit Misangyi Watts. OpenStax, Rice University. Frozen 964da1b4e0343a4607b8af1b49470a35faf55f96 source edition, CC BY 4.0; complete native paragraphs, whitespace normalised; third-party/media excluded.
Entrepreneurship — Michael Laverty; Chris Littel. OpenStax, Rice University. Frozen 9c67d18c5faaa4cdb4cd087ce684c742e14f4005 source edition, CC BY 4.0; complete native paragraphs, whitespace normalised; third-party/media excluded.
American Government 3e — Glen Krutz; Sylvie Waskiewicz. OpenStax, Rice University. CC BY 4.0; frozen commit dd9a37728e80d377f2be83c2a0085d3c6ef6854c; complete native paragraphs, whitespace normalised; third-party and media excluded.
Anatomy and Physiology 2e — J. Gordon Betts; Peter Desaix; Eddie Johnson; Jody E. Johnson; Oksana Korol; Dean Kruse; Brandon Poe; James A. Wise; Mark Womble; Kelly A. Young. OpenStax, Rice University. CC BY 4.0; frozen commit 3f855aef2941c1da9c01db904d45b129e26106f2; complete native paragraphs, whitespace normalised; third-party and media excluded.
Astronomy 2e — Andrew Fraknoi; David Morrison; Sidney C. Wolff. OpenStax, Rice University. CC BY 4.0; frozen commit 9d7e69a2e0c9a651ad42254b9a93b701a6b08c10; complete native paragraphs, whitespace normalised; third-party and media excluded.
Business Ethics — Stephen M. Byars; Kurt Stanberry. OpenStax, Rice University. CC BY 4.0; frozen commit 21122d7c873e27ef0f2f1bf0c395bd175b32d7be; complete native paragraphs, whitespace normalised; third-party and media excluded.
Principles of Economics 3e — David Shapiro; Daniel MacDonald; Steven A. Greenlaw. OpenStax, Rice University. CC BY 4.0; frozen commit d0e5fcf6df9363727b71970378671fb7a804fce3; complete native paragraphs, whitespace normalised; third-party and media excluded.
Microbiology — Nina Parker; Mark Schneegurt; Anh-Hue Thi Tu; Brian M. Forster; Philip Lister. OpenStax, Rice University. CC BY 4.0; frozen commit 3f4edff55fe6935eed59579a1dc2f7479b6ffc7d; complete native paragraphs, whitespace normalised; third-party and media excluded.
Chemistry 2e — Paul Flowers; Klaus Theopold; Richard Langley; William R. Robinson. OpenStax, Rice University. CC BY 4.0; frozen commit 9928441ef0badc3ff024c6a1fe2842c0048ea858; complete native paragraphs, whitespace normalised; third-party and media excluded.
Introduction to Intellectual Property — David Kline. OpenStax, Rice University. CC BY 4.0; frozen commit 55411cd2253d9d71104c7fe44c14ded7006585a8; complete native paragraphs, whitespace normalised; third-party and media excluded.
College Physics 2e — Paul Peter Urone; Roger Hinrichs. OpenStax, Rice University. CC BY 4.0; frozen commit 84147e8ddbb1a7d2689e235630b230e6b4f20480; complete native paragraphs, whitespace normalised; third-party and media excluded.
Introductory Statistics 2e — Barbara Illowsky; Susan Dean. OpenStax, Rice University. CC BY 4.0; frozen commit fc004a462a69bb1b64ac327c6dd1847899476e06; complete native paragraphs, whitespace normalised; third-party and media excluded.
Introductory Business Statistics 2e — Alexander Holmes; Barbara Illowsky; Susan Dean. OpenStax, Rice University. CC BY 4.0; frozen commit fc004a462a69bb1b64ac327c6dd1847899476e06; complete native paragraphs, whitespace normalised; third-party and media excluded.
Intermediate Algebra 2e — Lynn Marecek; Andrea Honeycutt Mathis. OpenStax, Rice University. CC BY 4.0; frozen commit bba5f5244066884797f730149d918e33f2beefd1; complete native paragraphs, whitespace normalised; third-party and media excluded.
Principles of Finance — Julie Dahlquist; Rainford Knight. OpenStax, Rice University. CC BY 4.0; frozen commit e1283a2ffc060e7eef593151de3642ed79e12466; complete native paragraphs, whitespace normalised; third-party and media excluded.
Writing Guide with Handbook — Michelle Bachelor Robinson; Maria Jerskey; Toby Fulwiler. OpenStax, Rice University. CC BY 4.0; frozen commit aa32f33d8a271aaca990eaaf9c28e050b0a25a67; complete native paragraphs, whitespace normalised; third-party and media excluded.
BC Reads: Adult Literacy Fundamental English - Reader 2 by Shantel Ivits. ©2015 Shantel Ivits. CC BY4.0. Download for free from the B.C. Open Collection: https://collection.bccampus.ca/. Complete original-prose native paragraphs; whitespace normalised; media, exercises and underlying poetry excluded.
BC Reads: Adult Literacy Fundamental English - Reader 3 by Shantel Ivits. ©2015 Shantel Ivits. CC BY4.0. Download for free from the B.C. Open Collection: https://collection.bccampus.ca/. Complete original-prose native paragraphs; whitespace normalised; media, exercises and underlying poetry excluded.
BC Reads: Adult Literacy Fundamental English - Reader 4 by Shantel Ivits. ©2015 Shantel Ivits. CC BY4.0. Download for free from the B.C. Open Collection: https://collection.bccampus.ca/. Complete original-prose native paragraphs; whitespace normalised; media, exercises and underlying poetry excluded.
Tourism and Hospitality in B.C. by Morgan Westcott (Editor), with Don Webster; Donna Owens; Eugene Thomlinson; Geoffrey Bird; Griff Tripp; Heather Knowles; Keith Henry; Kelley Glazer; Lynda Robinson; Micki McCartney; Morgan Westcott; Peter Briscoe; Ray Freeman; Rebecca Wilson-Mah; Terry Hood. ©2015 Capilano University. CC BY4.0. Frozen first-edition text (home citation dated2019); not current travel/legal/financial guidance. Download for free from the B.C. Open Textbook Collection: https://open.bccampus.ca/find-open-textbooks/. Complete native original prose; whitespace normalised; media, third-party quotations and dependent/exercise spans excluded.
BC Reads: Adult Literacy Fundamental English – Reader 5 by Shantel Ivits. ©2015 Shantel Ivits. CC BY 4.0. Download for free from the B.C. Open Collection: https://opentextbc.ca/abealfreader5/. Complete original-prose native paragraphs; whitespace normalised; media, exercises and short paragraphs excluded.
Original text only; images, audio and other media are excluded.
Where Did Nap Time Go? Why Older Kids Do Not Nap at School — Darshini Babu Ganesh; Meghna Pandey; Tracy Riggins; Rebecca M. C. Spencer; Rhea Tiwari; Mark Wehland; Sonya Leikin. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Improving Healthcare for Pregnant Women — José Belizán. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Space Radiation May Affect Male and Female Brains Differently — Robert G. Hinshaw; Cynthia A. Lemere. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

The Dilemma of Dividing Five Candies Between Two Children — Shoham Choshen-Hillel; Yair Nahari. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

How Looking at a Picture of a Loved One Can Improve Your Hearing — Shir Nagar; Boaz M. Ben-David; Mario Mikulincer. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

How Do We Recognize the Same Object From Different Angles? — Brittney Truong; David Murray; Anila Kankipati; Breyanna Collins; Jay Hegdé. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

The Nocebo Effect: The Placebo’s “Evil Twin” — Helena Hartmann; Jonas Potthoff; Livia Asan; Ulrike Bingel. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

How the Brain and Memory Grow Up Together — Angela Ji; Mary Lorenz; Sigalle Bahary; Tracy Riggins. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

How the Nose Responds to SARS-CoV-2, Cell by Cell — Faith Taliaferro; Jaclyn M. Long; José Ordovás-Montañés. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

On a Scale From “Tom” to “Jerry,” What Is Your Personality Like? — Natacha Henriquez; Pauline Hochheuser; Marianna Kotzamani; Ilaria Romanelli; Peter Prinzie; Ruth Van der Hallen. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

The CRISPR Revolution: Can We Change Genes for the Better? — Jennifer A. Doudna. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Body Image During Puberty: What Happens to How Kids Feel About Their Bodies? — Savannah R. Roberts; Sasha Gorrell; Daniel Le Grange. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Explore More! How New Environments May Boost Your Memory — Kreeta I. L. Kerkkänen; Marit F. L. Ruitenberg; Judith Schomaker. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Does the Heart Age Faster in Space? — Emil Rehnberg; Bjorn Baselet; Lorenzo Moroni; Sarah Baatout; Kevin Tabury. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

What is Similarity and How Can Scientists Measure it? — Eben Daggett; Michael C. Hout. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Gravitational Wave Detectors—Past, Present, and Future — Kip Stephen Thorne. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

What Makes Villains Evil Yet Fascinating? — Apeksha Srivastava; Frederick L. Coolidge. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Teeth can Tell a Story About Childhood! — Julia Biliato Javaroni; Larissa Sthefani Sales dos Santos; Juliana de Lima Gonçalves; Fabrício Kitazono de Carvalho; Francisco Wanderley Garcia de Paula-Silva. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Single-Cell Recording: An Inside Look at a Brain Cell’s Work — Cassandra L. Oberhauser; Michael C. Hout. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Fact or Fable: Your Guide to Fighting Misinformation — Katinka Dijkstra; Arwen Sienna Divera Mollenbrok; Giang Thi Quynh Nguyen; Guieane Elaiza Cijntje. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

What Can Happen When Brain Cells Communicate Improperly? — Margarita Maltseva; Kerstin Alexandra Klotz; Julia Jacobs. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Why Controlling Ticks is Important — Jéssica Waldman; Arlex Rodríguez-Durán; Shafi Ullah; Muhammad Numan; Luís Fernando Parizi; Lucas Tirloni; Abid Ali; Carlos Logullo; Itabajara da Silva Vaz Jr. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Unveiling the Power of Smart Coatings — Beatriz Fernandes; Marta Lima; Carina I. C. Crucho. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Tick Tock! It Is Time For Bed! — Nicholas John Constantinesco; Deylon Dianna Harkey; Lauren A. Fowler. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Filtration: Making Dirty Water Clean Enough to Drink — Mabore Jerida Raseala; Meladi Lerato Motloutsi; Funeka Matebese; Richard Motlhaletsi Moutloali. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Can Hugging a Soft Robotic Cushion Help When You Feel Worried? — Alice Haynes; Jessica L. Fielding; Annie Lywood; Christopher Kent; Jonathan Rossiter. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

From Chew to Poo—How a Food’s Structure Changes Digestion — Meinou N. Corstens; Ciarán Forde. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Towards SDG 12: Upcycling Biomass and Waste to Valuable Products — Lana Bader; Gyorgy Szekely. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Reading the Genes of Microbes to Stop Diseases From Spreading — Marc J. Struelens. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Flowers You Can Eat — Rey Castañeda-Rodríguez; Stanislav Mulík; Amparo Quiles; César Ozuna. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Say No to Norovirus: What It Is and Why It Matters — Andrew Marino; Danica Jekic; Jagtaj Matharoo; Siobhán Neville. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Changing Wobbles Into Wins: Helping Older Adults Stay Upright — Joshua W. Pate; Cathie Sherrington. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Who Can Donate An Organ? — Micaela Gentile; Umberto Maggiore. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Can T-Shirt Color Affect Young Athletes’ Tennis Performance in Hot Conditions? — Nicolas Robin; Robbin Carien; Shelly Ruart; Laurent Dominique. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Powering Our Lives With the Ocean: From Waves to Electricity — Nicolás Faedo; Bruno Paduano; Maria Luisa Celesti. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Wearables To Help Grandparents Find Their Way in the City — Angélique Montuwy; Aurélie Dommes. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

How Singing Helped the Voices of People Living With Parkinson’s — Tara Raessi; Arla Good; Frank A. Russo. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Meet the Brain’s DJs: Brain Rhythms Help us Understand Language — Lena Henke; Jule Nabrotzky; Lorenzo Titone; Lars Meyer; Katharina H. Menn. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Exercise and Nutrition for Building Strong Bones — Melina Christopoulos; Panagiota Klentrou. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Understanding Dementia: When Memory Lane is Not a Straight Road — Anastassia M. Mena; Francesca B. Santos; Laura Jamieson; Madeleine P. McKenzie; Keely Matsusaki; Antonio P. Strafella. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Can We Keep the Brain Energized as it Ages? — Polina Shichkova; Jay S. Coggan; Daniel Keller; Henry Markram. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Building Better With Virtual Tools — Carlo Ratti; Landry Signe; Izuru Takewaki. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Ideologically biased evaluation of evidence - A signal-detection approach to measure individual differences — Arne Stolp; Christine Finn; Carolin-Theresa Ziemer; Christian Thiel; Tobias Rothmund. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Curvularia lunata drives biodeterioration of PVC secondary cable insulation involving surface colonization, moisture retention and chemical deterioration — Yimeng Liu; Shiying Yan; Jian Zhang; Yiping Chen; Yue Zhou; Changyi Huang; Tianlan Jiang; Yu Gao; Hansheng Zhu; Hao Shi; Chaoyi Han; Fosheng Li; Jie Zhang; Jian Zhao; Mei Cao. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Optimization design of car door structure considering aesthetics and safety — Yu’an Ning; Kiesu Kim. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Impact of seed node position on network robustness under localized attacks — Masaki Chujyo; Shu Liu; Fujio Toriumi. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Statistical patterns in the Ethereum blockchain: Analysis of EOAs and smart contracts in ERC20 token network — Kundan Mukhia; S. R. Luwang; Md. Nurujjaman; Tanujit Chakraborty; Suman Saha; Chittaranjan Hens. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.
