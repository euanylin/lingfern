# Open reading source attribution

These are separate complete paragraphs, with whitespace normalised, from the fixed editions below. CC BY 4.0 applies to the licensed original prose only. No source media, table, exercise, footnote, borrowed quotation container or excluded third-party content is included. All records remain draft; this is not CEFR calibration.

- Psychology 2e: Rose M. Spielman; William J. Jenkins; Marilyn D. Lovett. OpenStax, Rice University. Source: https://github.com/openstax/osbooks-psychology/blob/e061043bf2f9e86ace51c4e8dc9555160f60a99d/collections/psychology-2e.collection.xml. Archive/home SHA256: 6be60580c7d640091e5406bf3c28ca9c5aa84b8de717cd5110ce11ba104c5435.
- Biology 2e: Mary Ann Clark; Jung Choi; Matthew Douglas. OpenStax, Rice University. Source: https://github.com/openstax/osbooks-biology-bundle/blob/d2779c2edfb435e75047325434fe2fe93d5aa120/collections/biology-2e.collection.xml. Archive/home SHA256: ad36c39c255b4b369765e8d7db8f0f41cc23074555e07649e13cf295ca79253e.
- Physical Geology - 2nd Edition: Steven Earle; Karla Panchuk. BCcampus. Source: https://opentextbc.ca/physicalgeology2ed/. Archive/home SHA256: bac292c654f85b96e17831f8db7b5ce9181e0d062f0f3a133aefc298a7fd4f71.
- Introduction to Sociology 3e: Tonja R. Conerly; Kathleen Holmes; Asha Lal Tamang. OpenStax, Rice University. Source: https://github.com/openstax/osbooks-introduction-sociology/blob/d35d5f3bdac40f93607d600134865d4f13ce1f9b/collections/introduction-sociology-3e.collection.xml. Archive/home SHA256: 93918f53e902eeab76e526924bf6807e3b3f04e1127f4bdb03b7b2b2d87d2a0b.
- U.S. History: P. Scott Corbett; Jay Precht; Volker Janssen; John M. Lund; Todd Pfannestiel; Paul Vickery; Sylvie Waskiewicz. OpenStax, Rice University. Source: https://github.com/openstax/osbooks-us-history/blob/046331cfcea0ac1b1a8fd461b3e6aae638845af3/collections/us-history.collection.xml. Archive/home SHA256: 522791e9ee96f31b4146759bdf6c54377222d1356816108431270d94f02b0dbb.

Physical Geology copyright 2019 Steven Earle, chapter 22 Karla Panchuk. Original exception policy: https://opentextbc.ca/physicalgeology2ed/front-matter/exceptions-to-the-cc-by-licence/ . All listed media exceptions are excluded.

Licence: https://creativecommons.org/licenses/by/4.0/ ; the complete unchanged legal code accompanies this package. OpenStax current-main editions are not admitted by these old-edition grants. Retain author/institution/source attribution and indicate changes on reuse. No endorsement is implied.

BC Reads: Adult Literacy Fundamental English – Reader 1 by Shantel Ivits, BCcampus (2015). CC BY 4.0. Download for free from the B.C. Open Collection: https://opentextbc.ca/abealfreader1/
Introduction to Business — Lawrence J. Gitman; Carl McDaniel; Amit Shah; Monique Reece; Linda Koffel; Bethann Talsma; James C. Hyatt. OpenStax, Rice University. Frozen 9d3b8c44e4567d207424bc92d4f7ceffb1a9dcd5 source edition, CC BY 4.0; complete native paragraphs, whitespace normalised; third-party/media excluded.
Organizational Behavior — J. Stewart Black; David S. Bright; Donald G. Gardner; Eva Hartmann; Jason Lambert; Laura M. Leduc; Joy Leopold; James S. O’Rourke; Jon L. Pierce; Richard M. Steers; Siri Terjesen; Joseph Weiss. OpenStax, Rice University. Frozen 54660e7c5d6b4495a796032457a70a94708f3eeb source edition, CC BY 4.0; complete native paragraphs, whitespace normalised; third-party/media excluded.
Principles of Management — David S. Bright; Anastasia H. Cortes; Eva Hartmann; K. Praveen Parboteeah; Jon L. Pierce; Monique Reece; Amit Shah; Siri Terjesen; Joseph Weiss; Margaret A. White; Donald G. Gardner; Jason Lambert; Laura M. Leduc; Joy Leopold; Jeffrey Muldoon; James S. O’Rourke. OpenStax, Rice University. Frozen 54660e7c5d6b4495a796032457a70a94708f3eeb source edition, CC BY 4.0; complete native paragraphs, whitespace normalised; third-party/media excluded.
Principles of Marketing — Maria Gomez Albrecht; Mark Green; Linda Hoffman; Jacqueline Babb; Lauren M. Donovan; Debra Ellerbrook; Lisa S. Goolsby; Jaciel Keltgen; Sarah M. Shepler; Deborah Toomey. OpenStax, Rice University. Frozen deb6e19777dc40f3c8861fad1a3fa319d91a940a source edition, CC BY 4.0; complete native paragraphs, whitespace normalised; third-party/media excluded.
Introduction to Anthropology — Jennifer Hasty; David G. Lewis; Marjorie M. Snipes; Todd A. Barnhardt; M. Anne Basham; Sharon Gursky; Laura Jarvis-Seibert; Saira A. Mehmood; Sydney Yeager. OpenStax, Rice University. CC BY 4.0 frozen source edition; complete native paragraphs, whitespace normalised; third-party/media excluded.
Introduction to Philosophy — Nathan Smith; Gregory Browne; Parish Conkling; Naomi Friedman; Allison Fritz; Daniel Garro; Jeremy Gallegos; Jon Gill; Gayle Horton; Maryellen Lo Bosco; Rebecca A. Longtin; Corey McCall; Kurt Stuke. OpenStax, Rice University. Frozen ec2804507cf93609bcdd72cc2f2f5aea054a8ae5 source edition, CC BY 4.0; complete native paragraphs, whitespace normalised; third-party/media excluded.
World History Volume 1, to 1500 — Ann Kordas; Ryan J. Lynch; Brooke Nelson; Julie Tatlock; Chris Bingley; Celeste Chamberland; Scott Corbett; Rick Gianni; Jennifer Lawrence; Jamie McCandless; Cristina Mehrtens; Anthony Miller; Abigail Owen; David Price; Kim Richardson; Christopher S Rose; Joseph Snyder; Christopher Thrasher; David Toye; Alexander Wathen; Grace Hunt Watkinson; Joel Webb. OpenStax, Rice University. Frozen dbe4cb6de157b506f07fab8c52ffe80704578f69 source edition, CC BY 4.0; complete native paragraphs, whitespace normalised; third-party/media excluded.
World History Volume 2, from 1400 — Ann Kordas; Ryan J. Lynch; Brooke Nelson; Julie Tatlock; Chris Bingley; Celeste Chamberland; Scott Corbett; Rick Gianni; Jennifer Lawrence; Jamie McCandless; Cristina Mehrtens; Anthony Miller; Abigail Owen; David Price; Kim Richardson; Christopher S Rose; Joseph Snyder; Christopher Thrasher; David Toye; Alexander Wathen; Grace Hunt Watkinson; Joel Webb. OpenStax, Rice University. Frozen dbe4cb6de157b506f07fab8c52ffe80704578f69 source edition, CC BY 4.0; complete native paragraphs, whitespace normalised; third-party/media excluded.
Introduction to Political Science — Mark Carl Rom; Masaki Hidaka; Rachel Bzostek Walker; Emilia B. Carvalho; Rebecca Eissler; Terri Susan Fine; Cassandra Khatri; Timothy Lim; Brenda Norton; Robert Postic; Joseph Prud’homme; Shyam Krishnan Sriram; Victoria Williams. OpenStax, Rice University. CC BY 4.0 frozen source edition; complete native paragraphs, whitespace normalised; third-party/media excluded.
College Success — Amy Baldwin; Lisa August; James Bennett; Larry Buland; Sabrina Mathues; Susan Monroe; MJ O’Leary; Ann Pearson; Joshua Troesh; Margit Misangyi Watts. OpenStax, Rice University. Frozen 964da1b4e0343a4607b8af1b49470a35faf55f96 source edition, CC BY 4.0; complete native paragraphs, whitespace normalised; third-party/media excluded.
Entrepreneurship — Michael Laverty; Chris Littel. OpenStax, Rice University. Frozen 9c67d18c5faaa4cdb4cd087ce684c742e14f4005 source edition, CC BY 4.0; complete native paragraphs, whitespace normalised; third-party/media excluded.
American Government 3e — Glen Krutz; Sylvie Waskiewicz. OpenStax, Rice University. CC BY 4.0; frozen commit dd9a37728e80d377f2be83c2a0085d3c6ef6854c; complete native paragraphs, whitespace normalised; third-party and media excluded.
Anatomy and Physiology 2e — J. Gordon Betts; Peter Desaix; Eddie Johnson; Jody E. Johnson; Oksana Korol; Dean Kruse; Brandon Poe; James A. Wise; Mark Womble; Kelly A. Young. OpenStax, Rice University. CC BY 4.0; frozen commit 3f855aef2941c1da9c01db904d45b129e26106f2; complete native paragraphs, whitespace normalised; third-party and media excluded.
Astronomy 2e — Andrew Fraknoi; David Morrison; Sidney C. Wolff. OpenStax, Rice University. CC BY 4.0; frozen commit 9d7e69a2e0c9a651ad42254b9a93b701a6b08c10; complete native paragraphs, whitespace normalised; third-party and media excluded.
Business Ethics — Stephen M. Byars; Kurt Stanberry. OpenStax, Rice University. CC BY 4.0; frozen commit 21122d7c873e27ef0f2f1bf0c395bd175b32d7be; complete native paragraphs, whitespace normalised; third-party and media excluded.
Principles of Economics 3e — David Shapiro; Daniel MacDonald; Steven A. Greenlaw. OpenStax, Rice University. CC BY 4.0; frozen commit d0e5fcf6df9363727b71970378671fb7a804fce3; complete native paragraphs, whitespace normalised; third-party and media excluded.
Microbiology — Nina Parker; Mark Schneegurt; Anh-Hue Thi Tu; Brian M. Forster; Philip Lister. OpenStax, Rice University. CC BY 4.0; frozen commit 3f4edff55fe6935eed59579a1dc2f7479b6ffc7d; complete native paragraphs, whitespace normalised; third-party and media excluded.
Chemistry 2e — Paul Flowers; Klaus Theopold; Richard Langley; William R. Robinson. OpenStax, Rice University. CC BY 4.0; frozen commit 9928441ef0badc3ff024c6a1fe2842c0048ea858; complete native paragraphs, whitespace normalised; third-party and media excluded.
Introduction to Intellectual Property — David Kline. OpenStax, Rice University. CC BY 4.0; frozen commit 55411cd2253d9d71104c7fe44c14ded7006585a8; complete native paragraphs, whitespace normalised; third-party and media excluded.
College Physics 2e — Paul Peter Urone; Roger Hinrichs. OpenStax, Rice University. CC BY 4.0; frozen commit 84147e8ddbb1a7d2689e235630b230e6b4f20480; complete native paragraphs, whitespace normalised; third-party and media excluded.
Introductory Statistics 2e — Barbara Illowsky; Susan Dean. OpenStax, Rice University. CC BY 4.0; frozen commit fc004a462a69bb1b64ac327c6dd1847899476e06; complete native paragraphs, whitespace normalised; third-party and media excluded.
Introductory Business Statistics 2e — Alexander Holmes; Barbara Illowsky; Susan Dean. OpenStax, Rice University. CC BY 4.0; frozen commit fc004a462a69bb1b64ac327c6dd1847899476e06; complete native paragraphs, whitespace normalised; third-party and media excluded.
Intermediate Algebra 2e — Lynn Marecek; Andrea Honeycutt Mathis. OpenStax, Rice University. CC BY 4.0; frozen commit bba5f5244066884797f730149d918e33f2beefd1; complete native paragraphs, whitespace normalised; third-party and media excluded.
Principles of Finance — Julie Dahlquist; Rainford Knight. OpenStax, Rice University. CC BY 4.0; frozen commit e1283a2ffc060e7eef593151de3642ed79e12466; complete native paragraphs, whitespace normalised; third-party and media excluded.
Writing Guide with Handbook — Michelle Bachelor Robinson; Maria Jerskey; Toby Fulwiler. OpenStax, Rice University. CC BY 4.0; frozen commit aa32f33d8a271aaca990eaaf9c28e050b0a25a67; complete native paragraphs, whitespace normalised; third-party and media excluded.
BC Reads: Adult Literacy Fundamental English - Reader 2 by Shantel Ivits. ©2015 Shantel Ivits. CC BY4.0. Download for free from the B.C. Open Collection: https://collection.bccampus.ca/. Complete original-prose native paragraphs; whitespace normalised; media, exercises and underlying poetry excluded.
BC Reads: Adult Literacy Fundamental English - Reader 3 by Shantel Ivits. ©2015 Shantel Ivits. CC BY4.0. Download for free from the B.C. Open Collection: https://collection.bccampus.ca/. Complete original-prose native paragraphs; whitespace normalised; media, exercises and underlying poetry excluded.
BC Reads: Adult Literacy Fundamental English - Reader 4 by Shantel Ivits. ©2015 Shantel Ivits. CC BY4.0. Download for free from the B.C. Open Collection: https://collection.bccampus.ca/. Complete original-prose native paragraphs; whitespace normalised; media, exercises and underlying poetry excluded.
Tourism and Hospitality in B.C. by Morgan Westcott (Editor), with Don Webster; Donna Owens; Eugene Thomlinson; Geoffrey Bird; Griff Tripp; Heather Knowles; Keith Henry; Kelley Glazer; Lynda Robinson; Micki McCartney; Morgan Westcott; Peter Briscoe; Ray Freeman; Rebecca Wilson-Mah; Terry Hood. ©2015 Capilano University. CC BY4.0. Frozen first-edition text (home citation dated2019); not current travel/legal/financial guidance. Download for free from the B.C. Open Textbook Collection: https://open.bccampus.ca/find-open-textbooks/. Complete native original prose; whitespace normalised; media, third-party quotations and dependent/exercise spans excluded.
BC Reads: Adult Literacy Fundamental English – Reader 5 by Shantel Ivits. ©2015 Shantel Ivits. CC BY 4.0. Download for free from the B.C. Open Collection: https://opentextbc.ca/abealfreader5/. Complete original-prose native paragraphs; whitespace normalised; media, exercises and short paragraphs excluded.
Original text only; images, audio and other media are excluded.
Going to School to Sculpt the Brain — Javier DeFelipe. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Brain–Machine Interfaces: Your Brain in Action — Jose M. Carmena; José del R. Millán. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Specialization of Functions in the Human Brain — Josef Parvizi. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

How Ventriloquism Works — Michael S. A. Graziano. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Drama in the Teenage Brain — Kathryn L. Mills; Anne-Lise Goddings; Sarah-Jayne Blakemore. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

What is Déjà vu? — Julia C. Teale; Akira R. O’Connor. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Twenty Tips for High-School Students Engaging in Research with Scientists — The Rainbow Investigators; Timothée Flutre; Mathilde Bonnefond; Guillaume Sescousse; Livio Riboli-Sasco. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Oops – That was a Mistake! How Toddler Brains React to Feedback — Marlene Meyer; Suhas Hassan Vijayakumar; Harold Bekkering; Denise J. C. Janssen; Ellen R. A. de Bruijn; Sabine Hunnius. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Can Money Buy You a Better Brain? What Do You Think? — Kristina Uban; Megan Herting; Elizabeth R. Sowell. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Seeing the Shadow of Rings around a “Super Saturn” — Matthew Kenworthy. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Getting Out of the Laboratory to Make Experiments Real: Can Sports Fans Influence Muay Thai Judges? — Tony D. Myers. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Connecting the Dots: Your Brain and Creativity — Dita Cavdarbasha; Jake Kurczek. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

The Wandering Mind: How the Brain Allows Us to Mentally Wander Off to Another Time and Place — Julia W. Y. Kam. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Waves of Perception — Bhargavi Ram; Randolph F. Helfrich. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Grateful People Are Happy and Healthy—But Why? — Anna Alkozei; Ryan Smith; William D. S. Killgore. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

The Jump-Roping Brain — Kate R. Zha; Jennifer Hyman; James M. Hyman. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

A Face Scavenger Hunt: Why We See Faces in Objects without Faces — Mary Nevins; Ashleigh Maxcey; Isabel Gauthier. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

A Friend Is a Treasure and May Help You to Face Bullying — Raúl Navarro; Santiago Yubero; Elisa Larrañaga. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Can Brain Training Train Your Brain? Using the Scientific Method to Get the Answer — Celia Goffin; Daniel Ansari. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

The 3Rs: What are Medical Scientists Doing about Animal Testing? — Rachel Tanner. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

How Do We Understand Sarcasm? — Penny M. Pexman. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Making Reality Virtual: How VR “Tricks” Your Brain — Rebecca A. Penn; Michael C. Hout. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

How to Discover a Planet Orbiting a Distant Star — Brett M. Morris. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Pupils: A Window Into the Mind — Alexis Torres; Michael C. Hout. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Action Recognition Happens Very Quickly in the Human Brain — Andrea Tacchetti; Leyla Isik. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Happy Gut Bacteria, Happy Brain: The Microbiota-Gut-Brain Axis — Juan M. Lima-Ojeda; Rainer Rupprecht; Thomas C. Baghai. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Recovery After a Stroke—Five Tips for Rehabilitation — Alana B. McCambridge. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

When Bacteria Go to Sleep — Orit Gefen; Nathalie Q. Balaban. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Trick or Treat? How Artificial Sweeteners Affect the Brain and Body — Hunter Myüz; Michael C. Hout. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Food for Thought: The Science Behind Dietary Guidelines — Stephanie R. Partridge; Rebecca Raeside; Stella Ruan; Anna Singleton. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Look Out! How Teams of Brain Cells Help Keep Us Safe From Harm — Lindsay R. Halladay. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Brain-Computer Interface Racing at the Cybathlon 2016 — Domen Novak; Roland Sigrist; Robert Riener. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

CTE: The Hidden Risk of Playing Contact Sports — Hamad Yadikar; Connor Johnson; Edwin Mouhawasse; Milin Kurup; Lynn Nguyen; Niko Pafundi; Kevin K. W. Wang. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Who Is the Most Important Character in Frozen? What Networks Can Tell Us About the World — Petter Holme; Mason A. Porter; Hiroki Sayama. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

The Intestinal Universe—Full of Gut Heroes Who Need Sidekicks — Bahtiyar Yilmaz; Joana C. Carvalho; Marta Marialva. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Telling Someone and Telling on Someone—Is There a Difference? — Michelle Kennedy; Larisa McLoughlin; Amanda Clacy. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

The New Astronomy: Observing Our Universe With Light and Gravity — Joey Shapiro Key; LIGO Scientific Collaboration. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Camouflaging in Autism — Laura Hull; Will Mandy. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

The Body’s Clock: Timekeeping With Food — Carolina M. Greco; Kevin B. Koronowski; Paolo Sassone-Corsi. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Stuttering and Its Invisibility: Why Does My Classmate Only Stutter Sometimes? — Hope Gerlach; Anu Subramanian; Elizabeth Wislar. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Alexander Fleming, The Discoverer of the Antibiotic Effects of Penicillin — Michal Letek. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Returning to School After a Concussion — Melissa McCart; Christina Karns; Meghan Ramirez; Matthew Dawson; Ann Glang. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

What Are Embryonic Stem Cells and How Can They Help Us? — Eran Meshorer. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Make Space: The Importance of Spatial Thinking for Learning Mathematics — Katie A. Gilligan. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Why Do We “Choke” Under Pressure? — Stefania A. Ciurea; Ashleigh M. Maxcey; Phillip M. Newman. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Dangerous Slimes: How Bacterial Biofilms Make You Sick and How to Combat Them — Hervé Poilvache; Françoise Van Bambeke. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

What Is COVID-19? — Gabriela Gama Freire Alberca; Iara Grigoletto Fernandes; Maria Notomi Sato; Ricardo Wesley Alberca. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Music and Learning: Does Music Make You Smarter? — Gabriella Musacchia; Alexander Khalil. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Can Toothache Cause Heartbreak? — Natasha Clark; Zoe Skinner; Catrin Sian Rutland. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Do You Feel Like You Belong? — Kelly-Ann Allen. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

How Many Ways Are There to Make a Black Hole? — Shamit Kachru. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

This Will Only Hurt for a Minute: How Our Brains Plan for Pain — Giovanna Del Sordo; Emma Moyer; Dre Goode; Michael C. Hout. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Puberty: Your Brain on Hormones — Katherine E. Kabotyanski; Leah H. Somerville. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Say Wart??? — Meihua Yu; Janin Chandra. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

COVID-19: The New Immune Challenge — Suleman R. Sabir; Emma C. Thomson; Tomasz J. Guzik; Fulvio D’Acquisto; Pasquale Maffia. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Connecting the Dots: Discovering the “Shape” of Data — Michelle Feng; Abigail Hickok; Yacoub H. Kureh; Mason A. Porter; Chad M. Topaz. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Double Empathy: Why Autistic People Are Often Misunderstood — Catherine J. Crompton; Kilee DeBrabander; Brett Heasman; Damian Milton; Noah J. Sasson. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Working Out Your Pain: Why Intense Exercise Is Painful — Marcel Berger; Daniel Henning; Michael C. Hout. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Do Smartphones Hurt Our Eyes by Causing Shortsightedness? — Saoirse Mccrann; James Loughman; John S. Butler; Daniel Ian Flitcroft. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Why Is Grandma Walking Strangely? — Tamaya Van Criekinge; Ann Hallemans. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Interactive 3D Brain Helps You Learn How the Brain is Organized — Paul S. Scotti; Arman P. Kulkarni; Matan Mazor; Eduard Klapwijk; Alexander Huth. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Are Your Muscles or Your Brain Making You Feel Tired After Exercise? — Derek Zhang; Juana Li; Ryan Miller; Marina Batraka; Sophie Marie Anne Effing; Fahmida Hossain; Anne-Catherine Bernard; Mathieu Marillier; Nicolle J. Domnik. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Speaking and Hearing With an Accent — John A. Archibald. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

What is Vitiligo and How Can it Teach Us a Crucial Life Lesson? — Nicholas Leonard; Jillian M. Richmond. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Attention: Your Brain’s Superpower — Taissa Lytchenko; Stanimira Seekins; Stephanie Huntamer; Tess White; Gideon P. Caplovitz; Ryan E. B. Mruczek. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

The Recycling System in Cells That Helps to Prevent Obesity — Carla Narro; Patricia Rivera; Eugenia Morselli. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Lessons From Lizards: How Scaly Superhealers Can Help Humans — Noeline Subramaniam; Kathy Jacyniak; Rebecca P. McDonald; Matthew K. Vickaryous. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Racism on the Brain — Claire Weichselbaum; Kira Hudson Banks. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Finding Your Way: Shortest Paths on Networks — Teresa Rexin; Mason A. Porter. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Listen With Your Wrists — Mark D. Fletcher. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

The “Creatures” in Your Head — Lasse Dissing-Olesen. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Tackling Noise Pollution With Slow Sound — William J. Parnell; William D. Rowley; Naomi R. M. Curati. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

How a Star’s Death Can Reveal a Black Hole — Iair Arcavi. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Are Humans More Like Wolves or Dogs? — Mati Breski; Daniel Dor. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Human Riddles in Behavioral Economics — Daniel Kahneman. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Why Are We so Scent-Imental? Studying Odor-Linked Memories — Angela-Faith Thomas; Megan H. Papesh. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Using Self-Compassion to Manage Difficult Sport Experiences — Leah J. Ferguson; Tara-Leigh F. Mchugh. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

How to See Pressure in Sport as a Challenge, Not a Threat — Carla Meijen; Martin J. Turner; Marc V. Jones. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Talent Development in Sport: How Do You Make It to the Top? — Camilla J. Knight; Victoria M. Gottwald. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

How Coaches, Parents, and Peers Influence Motivation in Sport — Richard James Keegan. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Why Should I Learn Music? It Can Be Good for Your Brain! — Bronte Ficek-Tani; Assal Habibi. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

I Can’t Hear Myself Think! How the Brain Deals With Talking in Noisy Environments — Sophie Meekings. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Can Vitamins Slow Down the Body’s Aging Process? — Chanachai Sae-Lee; Julien De Biasi; John C. Mathers. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

The “Little Person” in the Brain Who Helps to Direct Our Movements — Sofia Dall’Orso; Tiffany Hamstreet; Silvia Muceli. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Your Smile Caught My Eye: Why Do Emotional Things Catch and Hold Our Attention? — Andras N. Zsidó; Michael C. Hout. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Distant Planets and Big Promises: How to Detect Exoplanets and Whether They Have Life — Michel Mayor. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Why Is There Iodine in Table Salt? — Ayla Secio-Silva; Tatienne N. Figueira-Costa; Felipe Emrich; Ana F. Abrantes; Rodrigo A. Peliciari-Garcia; Paula Bargi-Souza. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Understanding The Odds: Statistics in Public Health — Gabriella Goodwin; So Young Ryu. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Can Computers Understand Humor? — Chen Shani; Dafna Shahaf. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

On the Hunt for Cancer’s Microbial “Party” in the Animal Kingdom — Gissel Marquez Alcaraz; Stefania E. Kapsetaki; Athena Aktipis; Corrie M. Whisner. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Green Chemistry—Sustainability at the Atom Scale — Jessica Streets; Amy-Louise Johnston; Hamza Ali; Hiba Azim; Peter Licence. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

What can Evolution Teach us About Being Sick? — Barbara Natterson-Horowitz; Daniel T. Blumstein. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Resolution Revolution—Seeing the Molecules of Life With Electron Cryomicroscopy — Noa Segev; Richard Henderson. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Seeing Beyond the Limits With Super-Resolution Microscopy — Eric Betzig. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

What is Culture? — Akshata R. Naik; Stephanie Baker; Changiz Mohiyeddini. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Causality: Using Math to Understand the Science of Cause and Effect — Frank Emmert-Streib; Matthias Dehmer. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Digital Tools For Youth Mental Health — Stephen M. Schueller; Trina Histon. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Wavelets: Mathematical Tools for Image Analysis — Ingrid Daubechies. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Game Theory—More Than Just Games — Robert Aumann. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.
