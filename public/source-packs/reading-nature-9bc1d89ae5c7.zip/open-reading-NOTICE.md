# Open reading source attribution

These are separate complete paragraphs, with whitespace normalised, from the fixed editions below. CC BY 4.0 applies to the licensed original prose only. No source media, table, exercise, footnote, borrowed quotation container or excluded third-party content is included. All records remain draft; this is not CEFR calibration.

- Psychology 2e: Rose M. Spielman; William J. Jenkins; Marilyn D. Lovett. OpenStax, Rice University. Source: https://github.com/openstax/osbooks-psychology/blob/e061043bf2f9e86ace51c4e8dc9555160f60a99d/collections/psychology-2e.collection.xml. Archive/home SHA256: 6be60580c7d640091e5406bf3c28ca9c5aa84b8de717cd5110ce11ba104c5435.
- Biology 2e: Mary Ann Clark; Jung Choi; Matthew Douglas. OpenStax, Rice University. Source: https://github.com/openstax/osbooks-biology-bundle/blob/d2779c2edfb435e75047325434fe2fe93d5aa120/collections/biology-2e.collection.xml. Archive/home SHA256: ad36c39c255b4b369765e8d7db8f0f41cc23074555e07649e13cf295ca79253e.
- Physical Geology - 2nd Edition: Steven Earle; Karla Panchuk. BCcampus. Source: https://opentextbc.ca/physicalgeology2ed/. Archive/home SHA256: bac292c654f85b96e17831f8db7b5ce9181e0d062f0f3a133aefc298a7fd4f71.
- Introduction to Sociology 3e: Tonja R. Conerly; Kathleen Holmes; Asha Lal Tamang. OpenStax, Rice University. Source: https://github.com/openstax/osbooks-introduction-sociology/blob/d35d5f3bdac40f93607d600134865d4f13ce1f9b/collections/introduction-sociology-3e.collection.xml. Archive/home SHA256: 93918f53e902eeab76e526924bf6807e3b3f04e1127f4bdb03b7b2b2d87d2a0b.
- U.S. History: P. Scott Corbett; Jay Precht; Volker Janssen; John M. Lund; Todd Pfannestiel; Paul Vickery; Sylvie Waskiewicz. OpenStax, Rice University. Source: https://github.com/openstax/osbooks-us-history/blob/046331cfcea0ac1b1a8fd461b3e6aae638845af3/collections/us-history.collection.xml. Archive/home SHA256: 522791e9ee96f31b4146759bdf6c54377222d1356816108431270d94f02b0dbb.

Physical Geology copyright 2019 Steven Earle, chapter 22 Karla Panchuk. Original exception policy: https://opentextbc.ca/physicalgeology2ed/front-matter/exceptions-to-the-cc-by-licence/ . All listed media exceptions are excluded.

Licence: https://creativecommons.org/licenses/by/4.0/ ; the complete unchanged legal code accompanies this package. OpenStax current-main editions are not admitted by these old-edition grants. Retain author/institution/source attribution and indicate changes on reuse. No endorsement is implied.

BC Reads: Adult Literacy Fundamental English – Reader 1 by Shantel Ivits, BCcampus (2015). CC BY 4.0. Download for free from the B.C. Open Collection: https://opentextbc.ca/abealfreader1/
Introduction to Business — Lawrence J. Gitman; Carl McDaniel; Amit Shah; Monique Reece; Linda Koffel; Bethann Talsma; James C. Hyatt. OpenStax, Rice University. Frozen 9d3b8c44e4567d207424bc92d4f7ceffb1a9dcd5 source edition, CC BY 4.0; complete native paragraphs, whitespace normalised; third-party/media excluded.
Organizational Behavior — J. Stewart Black; David S. Bright; Donald G. Gardner; Eva Hartmann; Jason Lambert; Laura M. Leduc; Joy Leopold; James S. O’Rourke; Jon L. Pierce; Richard M. Steers; Siri Terjesen; Joseph Weiss. OpenStax, Rice University. Frozen 54660e7c5d6b4495a796032457a70a94708f3eeb source edition, CC BY 4.0; complete native paragraphs, whitespace normalised; third-party/media excluded.
Principles of Management — David S. Bright; Anastasia H. Cortes; Eva Hartmann; K. Praveen Parboteeah; Jon L. Pierce; Monique Reece; Amit Shah; Siri Terjesen; Joseph Weiss; Margaret A. White; Donald G. Gardner; Jason Lambert; Laura M. Leduc; Joy Leopold; Jeffrey Muldoon; James S. O’Rourke. OpenStax, Rice University. Frozen 54660e7c5d6b4495a796032457a70a94708f3eeb source edition, CC BY 4.0; complete native paragraphs, whitespace normalised; third-party/media excluded.
Principles of Marketing — Maria Gomez Albrecht; Mark Green; Linda Hoffman; Jacqueline Babb; Lauren M. Donovan; Debra Ellerbrook; Lisa S. Goolsby; Jaciel Keltgen; Sarah M. Shepler; Deborah Toomey. OpenStax, Rice University. Frozen deb6e19777dc40f3c8861fad1a3fa319d91a940a source edition, CC BY 4.0; complete native paragraphs, whitespace normalised; third-party/media excluded.
Introduction to Anthropology — Jennifer Hasty; David G. Lewis; Marjorie M. Snipes; Todd A. Barnhardt; M. Anne Basham; Sharon Gursky; Laura Jarvis-Seibert; Saira A. Mehmood; Sydney Yeager. OpenStax, Rice University. CC BY 4.0 frozen source edition; complete native paragraphs, whitespace normalised; third-party/media excluded.
Introduction to Philosophy — Nathan Smith; Gregory Browne; Parish Conkling; Naomi Friedman; Allison Fritz; Daniel Garro; Jeremy Gallegos; Jon Gill; Gayle Horton; Maryellen Lo Bosco; Rebecca A. Longtin; Corey McCall; Kurt Stuke. OpenStax, Rice University. Frozen ec2804507cf93609bcdd72cc2f2f5aea054a8ae5 source edition, CC BY 4.0; complete native paragraphs, whitespace normalised; third-party/media excluded.
World History Volume 1, to 1500 — Ann Kordas; Ryan J. Lynch; Brooke Nelson; Julie Tatlock; Chris Bingley; Celeste Chamberland; Scott Corbett; Rick Gianni; Jennifer Lawrence; Jamie McCandless; Cristina Mehrtens; Anthony Miller; Abigail Owen; David Price; Kim Richardson; Christopher S Rose; Joseph Snyder; Christopher Thrasher; David Toye; Alexander Wathen; Grace Hunt Watkinson; Joel Webb. OpenStax, Rice University. Frozen dbe4cb6de157b506f07fab8c52ffe80704578f69 source edition, CC BY 4.0; complete native paragraphs, whitespace normalised; third-party/media excluded.
World History Volume 2, from 1400 — Ann Kordas; Ryan J. Lynch; Brooke Nelson; Julie Tatlock; Chris Bingley; Celeste Chamberland; Scott Corbett; Rick Gianni; Jennifer Lawrence; Jamie McCandless; Cristina Mehrtens; Anthony Miller; Abigail Owen; David Price; Kim Richardson; Christopher S Rose; Joseph Snyder; Christopher Thrasher; David Toye; Alexander Wathen; Grace Hunt Watkinson; Joel Webb. OpenStax, Rice University. Frozen dbe4cb6de157b506f07fab8c52ffe80704578f69 source edition, CC BY 4.0; complete native paragraphs, whitespace normalised; third-party/media excluded.
Introduction to Political Science — Mark Carl Rom; Masaki Hidaka; Rachel Bzostek Walker; Emilia B. Carvalho; Rebecca Eissler; Terri Susan Fine; Cassandra Khatri; Timothy Lim; Brenda Norton; Robert Postic; Joseph Prud’homme; Shyam Krishnan Sriram; Victoria Williams. OpenStax, Rice University. CC BY 4.0 frozen source edition; complete native paragraphs, whitespace normalised; third-party/media excluded.
College Success — Amy Baldwin; Lisa August; James Bennett; Larry Buland; Sabrina Mathues; Susan Monroe; MJ O’Leary; Ann Pearson; Joshua Troesh; Margit Misangyi Watts. OpenStax, Rice University. Frozen 964da1b4e0343a4607b8af1b49470a35faf55f96 source edition, CC BY 4.0; complete native paragraphs, whitespace normalised; third-party/media excluded.
Entrepreneurship — Michael Laverty; Chris Littel. OpenStax, Rice University. Frozen 9c67d18c5faaa4cdb4cd087ce684c742e14f4005 source edition, CC BY 4.0; complete native paragraphs, whitespace normalised; third-party/media excluded.
American Government 3e — Glen Krutz; Sylvie Waskiewicz. OpenStax, Rice University. CC BY 4.0; frozen commit dd9a37728e80d377f2be83c2a0085d3c6ef6854c; complete native paragraphs, whitespace normalised; third-party and media excluded.
Anatomy and Physiology 2e — J. Gordon Betts; Peter Desaix; Eddie Johnson; Jody E. Johnson; Oksana Korol; Dean Kruse; Brandon Poe; James A. Wise; Mark Womble; Kelly A. Young. OpenStax, Rice University. CC BY 4.0; frozen commit 3f855aef2941c1da9c01db904d45b129e26106f2; complete native paragraphs, whitespace normalised; third-party and media excluded.
Astronomy 2e — Andrew Fraknoi; David Morrison; Sidney C. Wolff. OpenStax, Rice University. CC BY 4.0; frozen commit 9d7e69a2e0c9a651ad42254b9a93b701a6b08c10; complete native paragraphs, whitespace normalised; third-party and media excluded.
Business Ethics — Stephen M. Byars; Kurt Stanberry. OpenStax, Rice University. CC BY 4.0; frozen commit 21122d7c873e27ef0f2f1bf0c395bd175b32d7be; complete native paragraphs, whitespace normalised; third-party and media excluded.
Principles of Economics 3e — David Shapiro; Daniel MacDonald; Steven A. Greenlaw. OpenStax, Rice University. CC BY 4.0; frozen commit d0e5fcf6df9363727b71970378671fb7a804fce3; complete native paragraphs, whitespace normalised; third-party and media excluded.
Microbiology — Nina Parker; Mark Schneegurt; Anh-Hue Thi Tu; Brian M. Forster; Philip Lister. OpenStax, Rice University. CC BY 4.0; frozen commit 3f4edff55fe6935eed59579a1dc2f7479b6ffc7d; complete native paragraphs, whitespace normalised; third-party and media excluded.
Chemistry 2e — Paul Flowers; Klaus Theopold; Richard Langley; William R. Robinson. OpenStax, Rice University. CC BY 4.0; frozen commit 9928441ef0badc3ff024c6a1fe2842c0048ea858; complete native paragraphs, whitespace normalised; third-party and media excluded.
Introduction to Intellectual Property — David Kline. OpenStax, Rice University. CC BY 4.0; frozen commit 55411cd2253d9d71104c7fe44c14ded7006585a8; complete native paragraphs, whitespace normalised; third-party and media excluded.
College Physics 2e — Paul Peter Urone; Roger Hinrichs. OpenStax, Rice University. CC BY 4.0; frozen commit 84147e8ddbb1a7d2689e235630b230e6b4f20480; complete native paragraphs, whitespace normalised; third-party and media excluded.
Introductory Statistics 2e — Barbara Illowsky; Susan Dean. OpenStax, Rice University. CC BY 4.0; frozen commit fc004a462a69bb1b64ac327c6dd1847899476e06; complete native paragraphs, whitespace normalised; third-party and media excluded.
Introductory Business Statistics 2e — Alexander Holmes; Barbara Illowsky; Susan Dean. OpenStax, Rice University. CC BY 4.0; frozen commit fc004a462a69bb1b64ac327c6dd1847899476e06; complete native paragraphs, whitespace normalised; third-party and media excluded.
Intermediate Algebra 2e — Lynn Marecek; Andrea Honeycutt Mathis. OpenStax, Rice University. CC BY 4.0; frozen commit bba5f5244066884797f730149d918e33f2beefd1; complete native paragraphs, whitespace normalised; third-party and media excluded.
Principles of Finance — Julie Dahlquist; Rainford Knight. OpenStax, Rice University. CC BY 4.0; frozen commit e1283a2ffc060e7eef593151de3642ed79e12466; complete native paragraphs, whitespace normalised; third-party and media excluded.
Writing Guide with Handbook — Michelle Bachelor Robinson; Maria Jerskey; Toby Fulwiler. OpenStax, Rice University. CC BY 4.0; frozen commit aa32f33d8a271aaca990eaaf9c28e050b0a25a67; complete native paragraphs, whitespace normalised; third-party and media excluded.
BC Reads: Adult Literacy Fundamental English - Reader 2 by Shantel Ivits. ©2015 Shantel Ivits. CC BY4.0. Download for free from the B.C. Open Collection: https://collection.bccampus.ca/. Complete original-prose native paragraphs; whitespace normalised; media, exercises and underlying poetry excluded.
BC Reads: Adult Literacy Fundamental English - Reader 3 by Shantel Ivits. ©2015 Shantel Ivits. CC BY4.0. Download for free from the B.C. Open Collection: https://collection.bccampus.ca/. Complete original-prose native paragraphs; whitespace normalised; media, exercises and underlying poetry excluded.
BC Reads: Adult Literacy Fundamental English - Reader 4 by Shantel Ivits. ©2015 Shantel Ivits. CC BY4.0. Download for free from the B.C. Open Collection: https://collection.bccampus.ca/. Complete original-prose native paragraphs; whitespace normalised; media, exercises and underlying poetry excluded.
Tourism and Hospitality in B.C. by Morgan Westcott (Editor), with Don Webster; Donna Owens; Eugene Thomlinson; Geoffrey Bird; Griff Tripp; Heather Knowles; Keith Henry; Kelley Glazer; Lynda Robinson; Micki McCartney; Morgan Westcott; Peter Briscoe; Ray Freeman; Rebecca Wilson-Mah; Terry Hood. ©2015 Capilano University. CC BY4.0. Frozen first-edition text (home citation dated2019); not current travel/legal/financial guidance. Download for free from the B.C. Open Textbook Collection: https://open.bccampus.ca/find-open-textbooks/. Complete native original prose; whitespace normalised; media, third-party quotations and dependent/exercise spans excluded.
BC Reads: Adult Literacy Fundamental English – Reader 5 by Shantel Ivits. ©2015 Shantel Ivits. CC BY 4.0. Download for free from the B.C. Open Collection: https://opentextbc.ca/abealfreader5/. Complete original-prose native paragraphs; whitespace normalised; media, exercises and short paragraphs excluded.
Original text only; images, audio and other media are excluded.
Understanding Marine Microbes, the Driving Engines of the Ocean — Anna Kopf; Julia Schnetzer; Frank Oliver Glöckner. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

“Boiling Water Is Not Too Hot for Us!”—Preferred Living Spaces of Heat-Loving Microbes — Skander Elleuche; Carola Schröder; Nadine Stahlberg; Garabed Antranikian. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Don’t Judge a Plant by Its Flowers — Riva Anne Bruenn; Valerie Lavenburg; Shayla Salzman. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

“Where Did My Friends Go?”: How Corn’s Microbe Partners Have Changed Over Time — Jennifer E. Schmidt; Amélie C. M. Gaudin. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Studying the Seeds for Clouds at the CERN Research Labs — Hamish Gordon. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Secret Gardens Under the Sea: What are Seagrass Meadows and Why are They Important? — Leanne Claire Cullen-Unsworth; Benjamin Lawrence Jones; Richard Lilley; Richard K. F. Unsworth. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

How Do Birds Cope with Losing Members of Their Group? — Sarah L. Firth; Josh A. Firth. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

How Do We Measure Rainfall? — Auguste Gires. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Even Superheroes Need Help Sometimes: Three Incredible Tales of Microbial Symbiosis — Cassie L. Ettinger; Laetitia G. E. Wilkins; Katherine E. Dahlhausen; Sonia L. Ghose; Daniel Oberbauer; Jonathan A. Eisen; David A. Coil. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Two Sides to a Wing: A Gene that Makes Butterfly Upper and Bottom Wing Patterns Different — Anupama Prakash. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Staying Safe on a Surf Beach: What Are Rip Currents? — Sebastian J. Pitman; Shari L. Gallop; Robert W. Brander. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Was Mesosaurus an Aquatic Animal? How Do We Know If an Ancient Species Was Aquatic or Terrestrial? — Pablo Núñez Demarco; Melitta Meneghel; Michel Laurin; Graciela Helena Piñeiro. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Evolution in a Bottle — César Aguilar. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

How Can We Help to Prevent Medicines From Polluting the Environment? — Helena de Oliveira Souza; Rafaela dos Santos Costa; Gabrielle Rabelo Quadra; Marcos Antonio Fernandez. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Harnessing the Heat Beneath Our Feet: Geothermal Energy — Susan Hamm; Elisabet Metcalfe. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

The Evolution of Bacteria Can Produce Chimeric Creatures: The Case of Azotobacter vinelandii — Gloria Soberón-Chávez. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Drought, Floods, Climate Change, and Forest Loss in the Amazon Region: A Present and Future Danger? — Jose A. Marengo. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

A Long Way From Home—Industrial Chemicals in the Arctic That Really Should Not Be There — Roxana Sühring; Miriam L. Diamond; Martin Scheringer; Liisa M. Jantunen. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Flower Power: A Close Look at Plant Reproduction — Katherine E. Dahlhausen; David A. Coil; Luca Comai; Isabelle M. Henry. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

What Wild Animals Do Kids Care About Most and Why Does It Matter? — M. Nils Peterson; Hannah G. Shapiro; Kathryn T. Stevenson; Kristin F. Mcnair; Randall Brian Langerhans. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Conquering the World: The Invasion of the Red Swamp Crayfish — Francisco Javier Oficialdegui. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Virginia Beached Sea Turtle Survey — Elyse Boudin; Bianca Santos; Frederique Carcaillet; David Kaplan. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

DVM: The World’s Biggest Game of Hide-and-Seek — Jennifer J. Freer; Laura Hobbs. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

How Do We Track Changing Arctic Sea Ice? — Olivia Lee. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

How Nutritious Will the Future Arctic Ocean Be? — Pearse J. Buchanan; Robyn E. Tuerena; Alessandro Tagliabue; Claire Mahaffey. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

The Arctic: An Upside-Down Ocean — Yueng Djern Lenn; Benjamin Lincoln; Markus Janout. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

How Melting Arctic Sea Ice Can Lead to Starving Polar Bears — Doreen Kohlbach; Benjamin A. Lange. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Getting Big Cows by Feeding Their Tiny Microbes — Brooke A. Clemmons; Emma Hernandez-Sanabria. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Following the Journey of Sea Turtles on Their Quest for Food — Aoife Taylor; Emilie Gerard; Hannah Haarmann; Mathilde Giry; Maike Heidemeyer. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

How Rare Are Rare-Earth Elements in Living Things? — Rocío Bustillos-Cristales; Yagul Pedraza-Pérez; Luis Ernesto Fuentes-Ramírez. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

How Introduced Earthworms Alter Ecosystems — Malte Jochum; Nico Eisenhauer. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Sharing Electrons: An Extraordinary Friendship Between Bacteria — Julia M. Otte. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Looking for Earthworms in Deadwood — Frank Ashwood; Elena I. Vanguelova; Sue Benham; Kevin R. Butt. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Non-wetting Materials — Valeri Frumkin; Moran Bercovici. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

The Agave Bat and Its Stinky Back Patch — Osiris Gaona; Carla Ximena Neri Barrios. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

The Way Soil Organisms Look Can Help Us Understand Their Importance — Pierre Ganault; Léa Beaumelle; Apolline Auclerc. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Flagship Species: Do They Help or Hurt Conservation? — Emily Moynes; Vishnu Prithiv Bhathe; Christina Brennan; Stephanie Ellis; Joseph R. Bennett; Sean J. Landsman. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

How do Scientists Use Sound to Count Fish in The Deep Sea? — Alina M. Wieczorek; Amanda Schadeberg; David G. Reid. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Who Feeds The Plants? Microbes! — Aline Lacaze; Antoine Zboralski; David L. Joly. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Are You a HAB Warrior? — Peggy W. Lehman; Tomofumi Kurobe; Timothy G. Otten; Melissa B. Peacock. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Small Shorebirds Feast On Green Slime To Fuel Their Long Migration — Laurie A. Hall; Susan E. W. De La Cruz; Isa Woo; Tomohiro Kuwae; David M. Nelson; John Y. Takekawa. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Crime Scene San Francisco: Who Is Responsible for the Disappearance of Delta Smelt? — Mallory E. Bedwell; Craig Stuart; Melinda R. Baerwald. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

A Message in a Bottle From the North Pole–How Plastic Pollutes the Arctic Ocean — Lisa W. von Friesen; Nanna B. Hartmann; Geir W. Gabrielsen; Sinja Rist. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Eating While the Eating’s Good: How Fire Creates a Magnet for Grazing Animals — Sherry A. Leis; Carol E. Baldwin. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Using Computers to Discover Materials That Generate Non-polluting Fuels — Santu Biswas; Maytal Caspary Toroker. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

What Are the Small Lumps I See on Some Plant Roots? — Fede Berckx; Katharina Pawlowski. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Helping Nature in the San Francisco Estuary Cope With Climate Change — Annika T. H. Keeley; Eva Bush; Dylan E. Chapple. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Branchflows: Upside-Down Rivers Clinging to the Bark Above Our Heads — John T. Van Stan II; Alexandra G. Ponette-González. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

We Make the Delta, and the Delta Makes us — Alejo Kraus-Polk; Julian Fulton. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

The Smallest Animals in the Water: Tiny but Mighty — Monika Winder; April Hennessy; Arthur Barros. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Microorganisms Floating Through the Air — Romie Tignat-Perrier; Nathalie Técher; Timothy M. Vogel; Catherine Larose; Aurélien Dommergue. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Microbial Mats: Primitive Structures That Could Help us Find Life on Other Worlds — Santiago Cadena; Paula Maza-Márquez; Sandra I. Ramírez Jiménez; Sharon L. Grim; José Q. García Maldonado; Leslie Prufert-Bebout; Brad M. Bebout. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Belowground Mountaineers: Critters Living in Mountain Soils — Michael Steinwandter; Julia Seeber. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Plant Litter Can Be Important Food for Stream Bugs — Checo Colón-Gaud; Keysa G. Rosas; José Sánchez-Ruiz; Pablo E. Gutiérrez-Fonseca; Alonso Ramírez. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

The Forest Graveyard: The Importance of Dead Trees, Bark, and Water — Anna Klamerus-Iwan; Ewa Błońska; Jarosław Lasota; John T. Van Stan. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Bacteria Can Unlock an Essential Nutrient for Plants — Jackson R. Hall; Andrew W. Sher; Tamas Varga; Sharon L. Doty. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

What Are Medusozoans, and Why Do They Sting? — José Agüero; Mariae C. Estrada-González; Leonela Rosales-Catalán; Ariadne Molina-Alonso; María A. Mendoza-Becerril. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

How Will Climate Change Affect Where You Live? — Carolina Viceto; Pat Wongpan; Alexander D. Fraser. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Do Lichens and Mosses Drink From Tree Bark? — Philipp Porada; Paolo Giordani. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

What Ice Cores can Tell us About Earth’s Past — Anne L. Myers; Alison S. Criscitiello. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

The Recovery of the American Peregrine Falcon in Alaska — David C. Payer; Melanie J. Flamme. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

The Impacts of Climate Change — Andrew J. Hartley; Ayesha Tandon. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Mangrove Madness: What Are Mangroves and Why Do We Care About Them? — Kevin R. T. Whelan; Michelle C. Prats. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Indicator Species Reveal Environmental Health — Sophie Phillips; Martha Merson; Nickolay I. Hristov; Louise Allen; Robert Brodman. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Cracking The Mystery Of Crater Lake’s Unique Newts — Andrew M. Ray; Stephen F. Spear; Scott F. Girdner; David K. Hering. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

How Plants and Bacteria can Clean the Earth — Leila Ordukhani; Andrea Firrincieli; John L. Freeman; Sharon L. Doty. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Do Parks Help Forests? — John Paul Schmit; Kathryn Miller; Elizabeth R. Matthews; Andrejs Brolis. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

How Does Cultural Burning Impact Biodiversity? — Kira M. Hoffman; Amy Cardinal Christianson; Emma L. Davis; Sara B. Wickham; Andrew J. Trant. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

An Antarctic Alga That Can Survive The Extreme Cold — David R. Smith; Arthur Leung; Xi Zhang; Marina Cvetkovska; Rachael Morgan-Kiss; Norman P. A. Hüner. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Fluffy Rivers: How Our Clothes Can Harm Rivers and The Oceans — Thomas Stanton; Matthew Johnson; Rachel Louise Gomes; Paul Nathanail; William Macnaughtan; Paul Kay. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

The Environmental Impact of Home Deliveries — Lynette Cheah; Qiuhong Huang. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Mr. and Mrs. Crab: How Can We Tell Them Apart? — Meng Hong Cheah; Hanafiah Fazhan; Rusydi Rozaimi; Khor Waiho. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

How Warm Gulf Stream Water Sustains a Cold Underwater Waterfall — Stefanie Semper; Mirjam S. Glessmer; Kjetil Våge; Robert S. Pickart. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

The Origin of Soft-Shell Crabs — Aorta Xian Lin Ling; Hanafiah Fazhan; Ghazali Azmie; Yushinta Fujaya; Khor Waiho. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

When Mediterranean Plant Diversity Profits From Wildfires — Amélie Fauché; Cécile Fleuriot; Solène Le Fur; Louis Ton; Frédérique Carcaillet; Christopher Carcaillet. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

How Scientists Forecast Volcanic Eruptions — Valerio Acocella. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Ocean Noise: The Human Footprint on Underwater Soundscapes — Ellen L. White; Nikhil Mistry; Paul R. White. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

How Might Climate Change Affect American Lobsters? — Winsor H. Watson; Steven H. Jury; Benjamin C. Gutzler; Thomas C. Lippmann; Jang-Geun Choi; Joshua T. Carloni; Jason S. Goldstein. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Salt: The Rock That Flows — Oscar Fernandez; Mark G. Rowan. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Future Food—Can Cultivated Meat Save Our Planet? — Paula Meyer; Lena Szczepanski; Milan Büscher; Julia Schächtele; Florian Fiebelkorn. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

How Can Art Assist Climate Science in Antarctica? — Gabby O’Connor; Natalie Robinson; Craig Stevens. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Big Mama Is Watching You—A Bedtime Story About How Giraffes Sleep — Anna Lena Burger; Paul W. Dierkes. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Insects—Nature’s Hidden Gems — Xin Rui Ong; Tharaka S. Priyadarshana; Li Si Tay; Marx Wen-Han Yim; Alexis Goh; Louisa May Fung; Eleanor M. Slade. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

The Rise and Fall of Continents — Donna L. Whitney; Jonas Vanardois; Jennifer M. Taylor; Christian Teyssier. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Contagious Cancers That Can Spread Between Ocean Organisms — Alicia L. Bruzos; Seila Diaz. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Salty, Brackish, Or Fresh—Saltiness Matters for Aquatic Species! — Leena Virta; Alf Norkko; Anna Villnäs. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Geothermal Heat Shapes the Antarctic Ice Sheet From Below — Tobias Stål; Felicity S. McCormack; Anya M. Reading; Niam Askey-Doran; Jacqueline A. Halpin; Mareen Lösing. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Predicting the Future: How Does a Weather Forecast Work? — Emma Holmberg; Christoffer Hallgren; Gabriele Messori. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Secrets Beneath Your Feet—The Fascinating World of Scientific Drilling — Aglaja Blanke; Ulrich Harms. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Whale Detectives Use Chemistry Clues to Uncover the Secret Lives of Beaked Whales — Kerri J. Smith; Tarla Rai Peterson; Markus J. Peterson. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Dung Beetles’ Life in Manure Helps Plants Grow — Sandra Milena Gelviz-Gelvez; Alfredo Ramírez-Hernández; Felipe Barragán. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Why Do Marine Mammals Strand on Land and How Can Humans Help? — Rebecca M. Boys; Karen A. Stockin; Katharina J. Peters. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

What Can Tapir Poop Teach Us About Healthy Forests? — Alfredo Yanez-Montalvo; Osiris Gaona; Arit de León-Lorenzana; Bernardo Águila; Luisa I. Falcón; Carla Ximena Neri-Barrios; Jonathan Pérez-Flores. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

What is Sustainability and How Do We Measure It? — Agnès Fargue-Lelièvre; Paola Clerino. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Kelp in a Changing Arctic Ocean — Megan Shipton; Anaïs Lebrun; Steeve Comeau. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

The Late Pleistocene Megafauna: Huge Animals that Used to Roam the Earth — Luciano Varela; Martín Batallés; P. Sebastián Tambusso; Richard A. Fariña. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Dealing With Wild Neighbors — Émilie Edelblutte; Robert Anderson; John Casellas Connors; Anne Short Gianotti. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Solving the Puzzle of Ecosystem Recovery — Helena S. Bayat; Julian Enß; Camilo Escobar-Sierra; Svenja M. Gillmann; Shaista Khaliq; Annabel Kuppels; Graciela M. Madariaga; Kristin Peters; Alexandra Schlenker; Daniel Hering; Matthijs Vos. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

How the Spread of Young Coral Can Help Save Coral Reefs — Ariel Greiner; Marco Andrello; Martin Krkošek; Marie-Josée Fortin. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.
