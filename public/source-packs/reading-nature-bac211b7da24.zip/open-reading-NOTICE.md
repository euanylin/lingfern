# Open reading source attribution

These are separate complete paragraphs, with whitespace normalised, from the fixed editions below. CC BY 4.0 applies to the licensed original prose only. No source media, table, exercise, footnote, borrowed quotation container or excluded third-party content is included. All records remain draft; this is not CEFR calibration.

- Psychology 2e: Rose M. Spielman; William J. Jenkins; Marilyn D. Lovett. OpenStax, Rice University. Source: https://github.com/openstax/osbooks-psychology/blob/e061043bf2f9e86ace51c4e8dc9555160f60a99d/collections/psychology-2e.collection.xml. Archive/home SHA256: 6be60580c7d640091e5406bf3c28ca9c5aa84b8de717cd5110ce11ba104c5435.
- Biology 2e: Mary Ann Clark; Jung Choi; Matthew Douglas. OpenStax, Rice University. Source: https://github.com/openstax/osbooks-biology-bundle/blob/d2779c2edfb435e75047325434fe2fe93d5aa120/collections/biology-2e.collection.xml. Archive/home SHA256: ad36c39c255b4b369765e8d7db8f0f41cc23074555e07649e13cf295ca79253e.
- Physical Geology - 2nd Edition: Steven Earle; Karla Panchuk. BCcampus. Source: https://opentextbc.ca/physicalgeology2ed/. Archive/home SHA256: bac292c654f85b96e17831f8db7b5ce9181e0d062f0f3a133aefc298a7fd4f71.
- Introduction to Sociology 3e: Tonja R. Conerly; Kathleen Holmes; Asha Lal Tamang. OpenStax, Rice University. Source: https://github.com/openstax/osbooks-introduction-sociology/blob/d35d5f3bdac40f93607d600134865d4f13ce1f9b/collections/introduction-sociology-3e.collection.xml. Archive/home SHA256: 93918f53e902eeab76e526924bf6807e3b3f04e1127f4bdb03b7b2b2d87d2a0b.
- U.S. History: P. Scott Corbett; Jay Precht; Volker Janssen; John M. Lund; Todd Pfannestiel; Paul Vickery; Sylvie Waskiewicz. OpenStax, Rice University. Source: https://github.com/openstax/osbooks-us-history/blob/046331cfcea0ac1b1a8fd461b3e6aae638845af3/collections/us-history.collection.xml. Archive/home SHA256: 522791e9ee96f31b4146759bdf6c54377222d1356816108431270d94f02b0dbb.

Physical Geology copyright 2019 Steven Earle, chapter 22 Karla Panchuk. Original exception policy: https://opentextbc.ca/physicalgeology2ed/front-matter/exceptions-to-the-cc-by-licence/ . All listed media exceptions are excluded.

Licence: https://creativecommons.org/licenses/by/4.0/ ; the complete unchanged legal code accompanies this package. OpenStax current-main editions are not admitted by these old-edition grants. Retain author/institution/source attribution and indicate changes on reuse. No endorsement is implied.

BC Reads: Adult Literacy Fundamental English – Reader 1 by Shantel Ivits, BCcampus (2015). CC BY 4.0. Download for free from the B.C. Open Collection: https://opentextbc.ca/abealfreader1/
Introduction to Business — Lawrence J. Gitman; Carl McDaniel; Amit Shah; Monique Reece; Linda Koffel; Bethann Talsma; James C. Hyatt. OpenStax, Rice University. Frozen 9d3b8c44e4567d207424bc92d4f7ceffb1a9dcd5 source edition, CC BY 4.0; complete native paragraphs, whitespace normalised; third-party/media excluded.
Organizational Behavior — J. Stewart Black; David S. Bright; Donald G. Gardner; Eva Hartmann; Jason Lambert; Laura M. Leduc; Joy Leopold; James S. O’Rourke; Jon L. Pierce; Richard M. Steers; Siri Terjesen; Joseph Weiss. OpenStax, Rice University. Frozen 54660e7c5d6b4495a796032457a70a94708f3eeb source edition, CC BY 4.0; complete native paragraphs, whitespace normalised; third-party/media excluded.
Principles of Management — David S. Bright; Anastasia H. Cortes; Eva Hartmann; K. Praveen Parboteeah; Jon L. Pierce; Monique Reece; Amit Shah; Siri Terjesen; Joseph Weiss; Margaret A. White; Donald G. Gardner; Jason Lambert; Laura M. Leduc; Joy Leopold; Jeffrey Muldoon; James S. O’Rourke. OpenStax, Rice University. Frozen 54660e7c5d6b4495a796032457a70a94708f3eeb source edition, CC BY 4.0; complete native paragraphs, whitespace normalised; third-party/media excluded.
Principles of Marketing — Maria Gomez Albrecht; Mark Green; Linda Hoffman; Jacqueline Babb; Lauren M. Donovan; Debra Ellerbrook; Lisa S. Goolsby; Jaciel Keltgen; Sarah M. Shepler; Deborah Toomey. OpenStax, Rice University. Frozen deb6e19777dc40f3c8861fad1a3fa319d91a940a source edition, CC BY 4.0; complete native paragraphs, whitespace normalised; third-party/media excluded.
Introduction to Anthropology — Jennifer Hasty; David G. Lewis; Marjorie M. Snipes; Todd A. Barnhardt; M. Anne Basham; Sharon Gursky; Laura Jarvis-Seibert; Saira A. Mehmood; Sydney Yeager. OpenStax, Rice University. CC BY 4.0 frozen source edition; complete native paragraphs, whitespace normalised; third-party/media excluded.
Introduction to Philosophy — Nathan Smith; Gregory Browne; Parish Conkling; Naomi Friedman; Allison Fritz; Daniel Garro; Jeremy Gallegos; Jon Gill; Gayle Horton; Maryellen Lo Bosco; Rebecca A. Longtin; Corey McCall; Kurt Stuke. OpenStax, Rice University. Frozen ec2804507cf93609bcdd72cc2f2f5aea054a8ae5 source edition, CC BY 4.0; complete native paragraphs, whitespace normalised; third-party/media excluded.
World History Volume 1, to 1500 — Ann Kordas; Ryan J. Lynch; Brooke Nelson; Julie Tatlock; Chris Bingley; Celeste Chamberland; Scott Corbett; Rick Gianni; Jennifer Lawrence; Jamie McCandless; Cristina Mehrtens; Anthony Miller; Abigail Owen; David Price; Kim Richardson; Christopher S Rose; Joseph Snyder; Christopher Thrasher; David Toye; Alexander Wathen; Grace Hunt Watkinson; Joel Webb. OpenStax, Rice University. Frozen dbe4cb6de157b506f07fab8c52ffe80704578f69 source edition, CC BY 4.0; complete native paragraphs, whitespace normalised; third-party/media excluded.
World History Volume 2, from 1400 — Ann Kordas; Ryan J. Lynch; Brooke Nelson; Julie Tatlock; Chris Bingley; Celeste Chamberland; Scott Corbett; Rick Gianni; Jennifer Lawrence; Jamie McCandless; Cristina Mehrtens; Anthony Miller; Abigail Owen; David Price; Kim Richardson; Christopher S Rose; Joseph Snyder; Christopher Thrasher; David Toye; Alexander Wathen; Grace Hunt Watkinson; Joel Webb. OpenStax, Rice University. Frozen dbe4cb6de157b506f07fab8c52ffe80704578f69 source edition, CC BY 4.0; complete native paragraphs, whitespace normalised; third-party/media excluded.
Introduction to Political Science — Mark Carl Rom; Masaki Hidaka; Rachel Bzostek Walker; Emilia B. Carvalho; Rebecca Eissler; Terri Susan Fine; Cassandra Khatri; Timothy Lim; Brenda Norton; Robert Postic; Joseph Prud’homme; Shyam Krishnan Sriram; Victoria Williams. OpenStax, Rice University. CC BY 4.0 frozen source edition; complete native paragraphs, whitespace normalised; third-party/media excluded.
College Success — Amy Baldwin; Lisa August; James Bennett; Larry Buland; Sabrina Mathues; Susan Monroe; MJ O’Leary; Ann Pearson; Joshua Troesh; Margit Misangyi Watts. OpenStax, Rice University. Frozen 964da1b4e0343a4607b8af1b49470a35faf55f96 source edition, CC BY 4.0; complete native paragraphs, whitespace normalised; third-party/media excluded.
Entrepreneurship — Michael Laverty; Chris Littel. OpenStax, Rice University. Frozen 9c67d18c5faaa4cdb4cd087ce684c742e14f4005 source edition, CC BY 4.0; complete native paragraphs, whitespace normalised; third-party/media excluded.
American Government 3e — Glen Krutz; Sylvie Waskiewicz. OpenStax, Rice University. CC BY 4.0; frozen commit dd9a37728e80d377f2be83c2a0085d3c6ef6854c; complete native paragraphs, whitespace normalised; third-party and media excluded.
Anatomy and Physiology 2e — J. Gordon Betts; Peter Desaix; Eddie Johnson; Jody E. Johnson; Oksana Korol; Dean Kruse; Brandon Poe; James A. Wise; Mark Womble; Kelly A. Young. OpenStax, Rice University. CC BY 4.0; frozen commit 3f855aef2941c1da9c01db904d45b129e26106f2; complete native paragraphs, whitespace normalised; third-party and media excluded.
Astronomy 2e — Andrew Fraknoi; David Morrison; Sidney C. Wolff. OpenStax, Rice University. CC BY 4.0; frozen commit 9d7e69a2e0c9a651ad42254b9a93b701a6b08c10; complete native paragraphs, whitespace normalised; third-party and media excluded.
Business Ethics — Stephen M. Byars; Kurt Stanberry. OpenStax, Rice University. CC BY 4.0; frozen commit 21122d7c873e27ef0f2f1bf0c395bd175b32d7be; complete native paragraphs, whitespace normalised; third-party and media excluded.
Principles of Economics 3e — David Shapiro; Daniel MacDonald; Steven A. Greenlaw. OpenStax, Rice University. CC BY 4.0; frozen commit d0e5fcf6df9363727b71970378671fb7a804fce3; complete native paragraphs, whitespace normalised; third-party and media excluded.
Microbiology — Nina Parker; Mark Schneegurt; Anh-Hue Thi Tu; Brian M. Forster; Philip Lister. OpenStax, Rice University. CC BY 4.0; frozen commit 3f4edff55fe6935eed59579a1dc2f7479b6ffc7d; complete native paragraphs, whitespace normalised; third-party and media excluded.
Chemistry 2e — Paul Flowers; Klaus Theopold; Richard Langley; William R. Robinson. OpenStax, Rice University. CC BY 4.0; frozen commit 9928441ef0badc3ff024c6a1fe2842c0048ea858; complete native paragraphs, whitespace normalised; third-party and media excluded.
Introduction to Intellectual Property — David Kline. OpenStax, Rice University. CC BY 4.0; frozen commit 55411cd2253d9d71104c7fe44c14ded7006585a8; complete native paragraphs, whitespace normalised; third-party and media excluded.
College Physics 2e — Paul Peter Urone; Roger Hinrichs. OpenStax, Rice University. CC BY 4.0; frozen commit 84147e8ddbb1a7d2689e235630b230e6b4f20480; complete native paragraphs, whitespace normalised; third-party and media excluded.
Introductory Statistics 2e — Barbara Illowsky; Susan Dean. OpenStax, Rice University. CC BY 4.0; frozen commit fc004a462a69bb1b64ac327c6dd1847899476e06; complete native paragraphs, whitespace normalised; third-party and media excluded.
Introductory Business Statistics 2e — Alexander Holmes; Barbara Illowsky; Susan Dean. OpenStax, Rice University. CC BY 4.0; frozen commit fc004a462a69bb1b64ac327c6dd1847899476e06; complete native paragraphs, whitespace normalised; third-party and media excluded.
Intermediate Algebra 2e — Lynn Marecek; Andrea Honeycutt Mathis. OpenStax, Rice University. CC BY 4.0; frozen commit bba5f5244066884797f730149d918e33f2beefd1; complete native paragraphs, whitespace normalised; third-party and media excluded.
Principles of Finance — Julie Dahlquist; Rainford Knight. OpenStax, Rice University. CC BY 4.0; frozen commit e1283a2ffc060e7eef593151de3642ed79e12466; complete native paragraphs, whitespace normalised; third-party and media excluded.
Writing Guide with Handbook — Michelle Bachelor Robinson; Maria Jerskey; Toby Fulwiler. OpenStax, Rice University. CC BY 4.0; frozen commit aa32f33d8a271aaca990eaaf9c28e050b0a25a67; complete native paragraphs, whitespace normalised; third-party and media excluded.
BC Reads: Adult Literacy Fundamental English - Reader 2 by Shantel Ivits. ©2015 Shantel Ivits. CC BY4.0. Download for free from the B.C. Open Collection: https://collection.bccampus.ca/. Complete original-prose native paragraphs; whitespace normalised; media, exercises and underlying poetry excluded.
BC Reads: Adult Literacy Fundamental English - Reader 3 by Shantel Ivits. ©2015 Shantel Ivits. CC BY4.0. Download for free from the B.C. Open Collection: https://collection.bccampus.ca/. Complete original-prose native paragraphs; whitespace normalised; media, exercises and underlying poetry excluded.
BC Reads: Adult Literacy Fundamental English - Reader 4 by Shantel Ivits. ©2015 Shantel Ivits. CC BY4.0. Download for free from the B.C. Open Collection: https://collection.bccampus.ca/. Complete original-prose native paragraphs; whitespace normalised; media, exercises and underlying poetry excluded.
Tourism and Hospitality in B.C. by Morgan Westcott (Editor), with Don Webster; Donna Owens; Eugene Thomlinson; Geoffrey Bird; Griff Tripp; Heather Knowles; Keith Henry; Kelley Glazer; Lynda Robinson; Micki McCartney; Morgan Westcott; Peter Briscoe; Ray Freeman; Rebecca Wilson-Mah; Terry Hood. ©2015 Capilano University. CC BY4.0. Frozen first-edition text (home citation dated2019); not current travel/legal/financial guidance. Download for free from the B.C. Open Textbook Collection: https://open.bccampus.ca/find-open-textbooks/. Complete native original prose; whitespace normalised; media, third-party quotations and dependent/exercise spans excluded.
BC Reads: Adult Literacy Fundamental English – Reader 5 by Shantel Ivits. ©2015 Shantel Ivits. CC BY 4.0. Download for free from the B.C. Open Collection: https://opentextbc.ca/abealfreader5/. Complete original-prose native paragraphs; whitespace normalised; media, exercises and short paragraphs excluded.
Original text only; images, audio and other media are excluded.
Playing Genetic Puzzles to Discover Unseen Majority of Tiny Ocean Organisms — Xin Sun. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Birds and Their Extraordinary Sense of Smell — Renee Li; Nivritti Mantha; Ichie Ojiro; Hiroaki Matsunami; Robert Driver. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Solar-Powered Life: How Plants And Other Organisms Produce Their Own Food — Lina Aragón; Kenneth J. Feeley. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Adventure in the Tropics: Joining Forces to Heal the Brazilian Atlantic Forest — Markus Gastauer; Angela S. Miazaki; Paulo A. Tavares; Eric D. S. M. Lino; Ricardo R. Rodrigues. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

The Foods We Choose Can Contribute to Climate Change — Adrian Leip; Göran Berndes; Diana Ürge-Vorsatz. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Wrack N’ Roll: The Ecological Role of Beach Wrack — Shannon Dee; Leah Beltran; Jessica Billinghurst; Paul S. Lavery; Oscar Serrano Gras; John W. Whale; Glenn Hyndes. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Methane, the Neglected Greenhouse Gas — Drew Shindell. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

What Can Insects Tell Us About Crimes? — Vinícius da Costa-Silva; Carina Mara de Souza; Luiz Antonio Lira; Catherine Sole; Patricia Jacqueline Thyssen. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Growing Up: Making Vertical Farms Even Smarter — Leo F. M. Marcelis; Elias Kaiser. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Aquatic Parasites: Tiny, Ancient Villains of Fish — Graciela Esmeralda Colunga-Ramírez; Gabor Cech; Boglarka Sellyei. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

What Drives Birdsong Evolution? — Eleanor M. Hay; Michelle E. Afkhami; Christopher A. Searcy. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Exploring Antibiotic Resistance in Earth’s Coldest Regions — Daniel Gattinger; Valentin Schlenz; Tobias Weil; Birgit Sattler. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Do You Know that there are Fungi in the Ocean? — Jennifer Arroyo; Jason E. Stajich; Cassie L. Ettinger. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Students Team up with Scientists to Investigate Salmon Vitamin Deficiencies — Abigail Ward; Margaret Harte. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Helping Crop Plants Adapt to Harsher Environments — Hanh Vo; Caitlin Dudley; Vanessa Tonet; Jazmine Humphreys; Eloise Foo. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Towards SDG 1: Helping Small Farmers by Saving Crops From Parasitic Weeds — Muhammad Jamil; Mohamed Salem; Salim Al-Babili. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Hi Forest, How are you Doing? — Silvana Munzi; Mariangela N. Fotelli; Caitlin R. Lewis; Mana Gharun; Rocío Alonso; Katerina Machacova. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Mysteries of Repetitive DNA Segments — Eva Šatović-Vukšić; Miroslav Plohl. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

The Living Meadow: How Mowing Affects Insects and Spiders — Margarita Hartlieb; Johanna L. Berger; Sonja N. K. Daum; Johanna Freudenberg; Florian Zenglein; Nina Janich; Nico Blüthgen. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

The Boiling River: A Hot Spot for Studying Climate Change in the Amazon — Kenneth J. Feeley; Alyssa T. Kullberg; Riley P. Fortier. Frontiers for Young Minds. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Arbuscular mycorrhizal fungi spore density and species diversity varied within plants species and between dry Afromontane forests in northwestern Ethiopia — Belay Berza Beyene; Workie Nibret Alamirew; Belayneh Asfaw Atnaf; Jemal Yimer Kebede; Marcela Claudia Pagano; Fassil Assefa Tuji. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Allometric equations for estimating tree volume and aboveground biomass of Acacia mangium Willd. on the Batéké Plateau, Republic of the Congo — Chelton Desarmes; Grace Jopaul Loubota Panzou; Flore Hirsch; Paul Bertaux; Nicolas Bayol. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Incentives are effective but insufficient to halt smallholder deforestation in the Colombian Amazon — Hugo Charoud; Esteve Corbera; Lina Moros; Sébastien Costedoat; Santiago Izquierdo-Tort. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Automated and quantitative characterization of benthic habitat and associated biological communities of an unknown southeast Pacific seamount — Yakufu Niyazi; Denise J. B. Swanborn; Jan M. Tapia-Guerra; Javier Sellanes; Erin E. Easton; Germán Zapata-Hernández; Heather A. Stewart; Alan J. Jamieson. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Generalism vs. specialization: Does niche breadth influence species responses to anthropogenic land-use change in Neotropical leaf-cutter ants? — Diego Garcia Castillo. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

A freshwater resilient and connected network to sustain biodiversity under a changing climate — Mark G. Anderson; Arlene P. Olivero; Analie R. Barnett; Mary L. Khoury; Erik H. Martin. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Habitat suitability assessment of mouflon applying a comparative approach on expert-based and species distribution models — Azita Rezvani; Shekoufeh Nematollahi; Davoud Fadakar; Sedighe Abdollahi; Sima Fakheran. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Beyond Gir: Barda wildlife sanctuary as a potential stronghold for Asiatic lions — Mohan Ram; Aradhana Sahu; Nityanand Srivastava; Rohit Chaudhary; Lahar Jhala; Yashpal Zala. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

The risk of thiamine deficiency in common eider ducklings increases when females consume large prey — Maciej J. Ejsmond; Anna Ejsmond; Marc M. Hauber; Jón Einar Jónsson; Andreas M. Waser; Samuel Hylander. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Tree diversity and standing carbon stocks in smallholder forests of Ciamis Regency, Indonesia: Effects of cropping patterns and elevations — Mohamad Siarudin; San Afri Awang; Ronggo Sadono; Priyono Suryanto; Muhammad Abdul Qirom; Budi Mulyana; Antun Puspanti; Donny Wicaksono; Fatahul Azwar; Said Fahmi; Freddy Jontara Hutapea. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Shotgun metagenomic profiling of the fecal microbiome in Lamp2 knockout mice reveals limited genotype-associated differences under standard housing — Maria Emfietzoglou; Maria Anna Bantounou; Shewa Osmani; Toshio Narimatsu; Konstantinos G. Baroutis; Alexandra Varsamidaki; Dimitra Skondra; Dimitris Papaconstantinou; Panagiotis Theodossiadis; Irini Chatziralli; Joan W. Miller; Demetrios G. Vavvas. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Advancing annually resolved oxygen isotope dendrochronology to overcome wood-dating limitations in the Euro-Atlantic region — Clara Rodríguez-Morata; Darren Davies; Neil J. Loader; Danny McCarroll; Sjoerd Van Daalen; Kristof Haneca; Valerie Daux; Marta Domínguez-Delmás. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Out of sight, hidden into the deep: Marine litter in the Mar del Plata Submarine Canyon (southwestern Atlantic) revealed by ROV survey — Valeria Teso; Diego Urteaga; Graziella Bozzano; Gregorio Bigatti; Martín I. Brogger; Francisco Brusa; Rodrigo Calderón; Nadia Cerino; Ignacio L. Chiesa; María Agustina Conti; Cristina Damborenea; María Carla de Aranzamendi; Brenda L. Doti; Nahuel Farías; Jonathan N. Flores; Santiago Herrera; Ezequiel Mabragaña; Mariano Martinez; Florencia Matusevich; Adriana Menoret; Emiliano Ocampo; Leonel Pacheco; Guido Pastorino; Pablo Penchaszadeh; Emanuel Pereira; Renata M. Pertossi; Jessica Risaro; Noelia C. Sánchez; Javier H. Signorelli; Marcos Tatián; Johanna N. J. Weston; Daniel Lauretta. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Virus-host interactions in iron-oxidizing mats of the East Pacific Rise — Kathryn L. Campbell; Jason B. Sylvan; Craig L. Moyer; Heather Fullerton; Jessica M. Labonté. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Two regions, two lineages: Untangling two centuries of confusion between Machilus glaucescens and M. macranthus (Lauraceae) through integrative taxonomy — Nabasmita Malakar; Ravikanth Gudasalamani; Ganesan Rengaian. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Mapping coastal forest retreat using convolutional neural networks and different satellite imagery — Titilayo T. Tajudeen; Marcelo Ardon; Mirela Tulbure; Katherine L. Martin. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Lessons learned from two applied approaches for treatment of aged DDT-contaminated soil with white-rot fungi — Stephanie Casey; Karin Wiberg; Anna-Karin Dahlberg; Malin Hultberg; Anja Enell; Yevheniya Volchko. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Recovery of a New England salt marsh six years after a natural sediment deposition event — Gregg E. Moore; Jennifer L. Gibson; David M. Burdick; Alondra Ortiz-Franco; Ashley N. Bulseco. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Agricultural expansion and mining drive forest loss in Ghana despite declining deforestation rates: Evidence from a national-scale assessment — Patrick Addo-Fordjour; Francis Emmanuel Awortwi; Caleb Ezekiel Obodai; Francis Boakye Aboagye; Christine Naa Lamiley France; Nana Serwaa Boakye Kusi-Appiah; Derrick Oppong. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Benthic communities on recent and historical volcanic lava flows of an oceanic island — Aitor Ugena; Sara González-Delgado; Iván Cano; Marina Aliende-Hernández; Beatriz Alfonso; José Carlos Hernández. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Parasite hideouts: Preserving native cavity-nesting Hymenoptera through pollinator hotel management — Bailey B. Lankford; Maria Escobedo; Sylvia Yoo; Elsa Youngsteadt; Denis S. Willett; Camila C. Filgueiras. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Bird-plant frugivory networks in two secondary Araucaria forests in southern Brazil — Francisco A. Vásquez-Arévalo; Pamela E. Malmoria; Carla S. Fontana; Pedro Maria Abreu Ferreira. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Ecological sensitivity and sustainable spatial planning in a highly urbanized plain: An AHP-GIS and geodetector approach in the Yangtze River Delta Plain — Tiantian Yao; Qian Liu; Huiqin Zeng; Jiabin Tang. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Evaluation of photoinhibition and development of stress tolerance index to identify photosynthetically adapted and stress tolerant germplasm accessions of tepary bean — Juan Carlos Suárez; Amara Tatiana Contreras; Idupulapati M. Rao. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Multi-locus genome-wide association analysis of grain yield, plant height, panicle length, and flowering time in the Senegalese pearl millet [Pennisetum glaucum (L.) R. Br.] germplasm — Aliou Ba; Oumar Diack; Thomas L. Odong; Safiétou Tooli Fall; Richard Edema; Arfang Badji; Adama Faye; Tonny Obua; Mildred Ochwo-Ssemakula; Paul Gibson; Mamadou Mar; Jessica B. Bacourine; Yagouba Diao; Mahoussi K. Arnaud Djanta; Ndjido A. Kane; Phinehas Tukamuhabwa. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Emergy evaluation of ecological sustainability in Cananguchales (Mauritia flexuosa): A biocountable approach in the Amazonian foothills — Víctor Julio Balanta Martínez; Oscar Fabian Patiño Perdomo; Faver Álvarez. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Mitochondrial genome-derived microsatellites reveal genetic diversity and population structure in Callery pear populations — Alina Pokhrel; Denita Hadziabdic; Robert N. Trigiano; William E. Klingeman; David R. Coyle; Marcin Nowicki. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Diversity at the HYP1 locus in potato cyst nematodes does not result from developmentally-programmed somatic mutations — Vincent C. T. Hanlon; Unnati Sonawala; Cian A. A. Raza; Luisa Kalkert; George Harpum; Lukas A. Burkhardt; Johannes Helder; Sebastian Eves-van den Akker. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Influence of weather variables on population dynamics of rice insect pests and their natural enemies: A six year light trap study in Gazipur, Bangladesh — Tapon Kumar Roy; Mir Md Moniruzzaman Kabir; Md Nazmul Bari; Md Mosaddeque Hossain; Anamika Sannal. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Soil organic carbon stocks, litter decomposition, and soil macrofauna diversity across contrasting land uses within a dual-purpose cattle farm in the Colombian Amazonian foothills — Juan Pablo Narváez-Herrera; Joaquín Angulo-Arizala; Wilson Andrés Barragán-Hernández; Henry Mavisoy-Muchavisoy; Adrian Rolando Riascos-Vallejos; Liliana Mahecha-Ledesma. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Genetic diversity and population structure of early-maturing yellow and orange maize inbred lines for improved breeding applications — Neo Jeremiah Mahula; Idris Ishola Adejumobi; Julius Akinyemi Fagbayide; Baffour Badu-Apraku; John Derera. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Investigation of glacier mass balance based on multi-source observation in the Karakoram over the past 25 years — Aijie Yu; Hongling Shi; Hubiao Wang; Zhiping Jiao; Ping Wang; Chunchun Gao; Harald Schuh. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Genome-wide assessment of genetic diversity and population structure of Capsicum in Southwestern Colombia using DArTseq markers — Ronald Andrés Viáfara-Vega; Heiber Cárdenas-Henao. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Land use change reshaped soil carbon dynamics in Northern China — Yuanyuan Tang; Yuchun Yang; Guohong Du; Yanbing Qi. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Using GIS, remote-sensing and linear modeling to prioritize spatially explicit action against erosion and sediment transport within Lake Victoria watershed in Kenya — Nickson Erick Otieno. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

The impact of the estrous cycle on the vaginal microbiota of dairy cows — Anne Kemmer Souza; Adèle Giroux; Amanda Fonseca Zangirolamo; Ricardo Guella Droher; Francieli Gesleine Capote Bonato; Amauri Alfieri; Gustavo Zamberlam; Marcelo Marcondes Seneda; Márcio Costa. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Soil aggregate stability and its influencing factors in Picea Schrenkiana var. Tianschanica forests of the Central Tianshan Mountains — Yuwen Chen; Weixia Wang; Shanchao Zhao; Xuansheng Huang; Haodong Yang; Yubo Sun; Xiaoli Ma; Weiye Du; DongLin Zhang; Zhimin Xi. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Vegetation cover change and classification-based zonation of Fanjing Mountain using google earth engine — Rongrong Wang; Wengang Cui; Suihua Liu; Ting Yu; Fei Ning; Qingsong Xu; Dan Hu. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.

Integrating images, sounds, citizen science and AI to assess the biodiversity of the Atlantic Forest of Brazil — Manoel Luis Costa; Claudia Mermelstein. PLOS ONE. CC BY 4.0; complete original native paragraphs, whitespace normalised; media and third-party quotations excluded.
Creative Commons Attribution 4.0 International (CC BY 4.0). Article-specific original grant; images, quoted third-party text and excluded material omitted.
