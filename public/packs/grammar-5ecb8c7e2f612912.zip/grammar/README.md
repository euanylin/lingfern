# Lingfern 英语用法词典

[Lingfern](https://lingfern.com)

`entries.json` 是 Lingfern 原创的离线英语用法参考。当前有 191 条疑问式词条。简体中文、繁体中文和英文的问题、简答、详细用法与易错处写在词条内；日语、韩语、法语、西班牙语、德语、葡萄牙语、意大利语、俄语、阿拉伯语、印地语和印尼语的对应说明在 `i18n/`。英文结构、例句和对比保持英文。覆盖基本时态与句式、限定词与介词、从句与情态、被动与使役等核心语法，并补充常见易混用法；按关键词检索或按首字母浏览。词条不附 CEFR 等级：单项语法现象不能可靠代表整体语言能力，也没有逐条分级验证。内容是有限范围的原创参考，不表示完整覆盖或权威分级。

## 可复用资料筛选（2026-09-27）

| 候选 | 已核对的授权与内容 | 本次决定 |
|---|---|---|
| [*Practical English Usage*（Oxford University Press）](https://india.oup.com/product/practical-english-usage-fourth-international-edition-9780194202466/)及 [Cambridge Grammar](https://dictionary.cambridge.org/us/grammar/british-grammar/) | 商业出版参考资料；[Cambridge 明确声明网页内容受版权保护](https://dictionary.cambridge.org/about.html)，未找到可将这些词条复制、翻译并作为 Lingfern 离线资源分发的公开许可 | 仅参考问题式组织方式和语法事实，未复制词条或例句 |
| [Wikibooks: English Grammar](https://en.wikibooks.org/wiki/English_Grammar) | [Wikibooks 版权政策](https://en.wikibooks.org/wiki/Wikibooks:Copyrights)允许按 CC BY-SA 4.0 复制和改编，并要求署名、以相同许可分享改编文本；现有内容按教材章节组织，主要面向英语母语语法教学 | 可作为独立的同许可资源候选，但不直接混入本项目计划中的原创 CC BY 词条；本次未复制 |
| [Brehe’s Grammar Anatomy](https://open.umn.edu/opentextbooks/textbooks/717) | 开放教科书资料页列 CC BY-SA；面向已掌握英语、学习基础语法概念的人，形式为教材而非用法词典 | 未直接复用，未复制 |
| [College ESL Writers](https://open.umn.edu/opentextbooks/textbooks/568) | 开放教科书资料页列 CC BY-NC-SA；供中高级英语学习者使用 | 非商业与相同方式共享限制不适合当前计划中的许可目标；未复制 |

本轮重点核对了 [Cambridge 的 because/because of](https://dictionary.cambridge.org/grammar/british-grammar/because-because-of-and-cos)、[either/neither](https://dictionary.cambridge.org/grammar/british-grammar/neither-neither-nor-and-not-)、[动词补语结构](https://dictionary.cambridge.org/grammar/british-grammar/verb-ing) 和 [Practical English Usage 出版介绍](https://india.oup.com/product/practical-english-usage-fourth-international-edition-9780194202466/)；新增解释与例句均重新编写。以上资料可用于核查事实与设计选题，不能把“网上可阅读”误作可自由复制。CC BY-SA 改编的同许可要求也见 [Creative Commons 兼容许可说明](https://creativecommons.org/compatible-licenses/)。当前三语问题式内容、例句与解释均为本项目新写；这里的链接是研究记录，不是运行时依赖。原创内容适用项目的 CC BY 4.0 许可；所列第三方资料保留各自条款。

## 维护与使用

资料库提供关键词检索、首字母浏览和逐条展开，安装资源后可离线查阅。界面语言为简体中文、繁体中文或英文时直接使用词条内的说明；其余十一种界面语言读取对应的 `i18n/<locale>.json`，读取失败时回退英文说明。英文例句、结构和对比始终保持从左到右的英文。更新时同时检查英文解释、例句、简繁中文和其余界面语言的说明，保留来源边界，不复制商业词典条目。原始 `reviewStatus` 是内容创建时的来源记录，不代表增加一项人工签署要求。新增条目应服务实际查询需求；先补基本语法空缺，再补常见易混用法。
