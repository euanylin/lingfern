John F. Kennedy. Address before the United Nations, 20 September 1963. https://www.presidency.ucsb.edu/documents/address-before-the-18th-general-assembly-the-united-nations

Original text and original human recording: Public domain — original US federal-government address. Specific collection-time grant: https://www.jfklibrary.org/asset-viewer/archives/jfkwha-218. Original audio: https://upload.wikimedia.org/wikipedia/commons/9/91/John_F._Kennedy_speaks_before_the_UN_General_Assembly%2C_September_20%2C_1963.ogg. Original SHA256 df54fb089de10170623fbd16c57b238207c80e65d3895f53681d6d3e9f2dfb82. Source capture SHA256 a5853cdd96074ed14f6cb9e4601a8667a317e2b81b77ca644e5010df0c050a51.

Exact continuous original audio 0–93.6 seconds, mono 16kHz 64kbps MP3 crop by Lingfern. No synthesis, gain limiting, filler, concatenation or endorsement. Only first four original native paragraphs; university editorial notes/photos excluded. Official written rendering with explicit retained ASR disagreements; no phoneme or audition claim.

Source-only package, lessons=[]; generated on the client. Exact local teaching scope only; original authored-draft approved:false registrations, precise holds and source-specific/regional release conditions retained. No whole-source or production/publication approval. No actual audition or physical-device claim. Keep credits, sources and this modification notice.
