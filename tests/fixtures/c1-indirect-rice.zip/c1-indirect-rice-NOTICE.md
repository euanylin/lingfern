John F. Kennedy. Address at Rice University on the space effort, 12 September 1962. https://www.rice.edu/kennedy

Original official US federal-government address and specific JFK archival original recording: public domain. Reused collection-time grant: https://www.jfklibrary.org/asset-viewer/archives/jfkwha-127-002
Original official transcript: https://www.jfklibrary.org/archives/other-resources/john-f-kennedy-speeches/rice-university-19620912
Preserved university edition: https://www.rice.edu/kennedy
Original recording file and retained file description: https://upload.wikimedia.org/wikipedia/commons/5/50/Jfk_rice_university_we_choose_to_go_to_the_moon.ogg ; https://commons.wikimedia.org/wiki/File:Jfk_rice_university_we_choose_to_go_to_the_moon.ogg
Original source/audio hashes, continuous window, source-bound transcript, technical checks and retained ASR disagreements are recorded in the local preparation evidence. No modern notes, images, music, rights of other speakers or uninspected remainder are granted. Local source-only import; regional/source-specific publication pending. No whole-source/public-release approval. Original authored drafts and independent-check constraints remain unchanged.
