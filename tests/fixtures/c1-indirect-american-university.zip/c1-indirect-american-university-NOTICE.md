John F. Kennedy. Commencement address at American University, 10 June 1963. https://www.presidency.ucsb.edu/documents/commencement-address-american-university-washington

Original official US federal-government address and specific JFK archival original recording: public domain. Reused collection-time grant: https://www.jfklibrary.org/asset-viewer/archives/jfkwha-190-002
Original official transcript: https://www.jfklibrary.org/archives/other-resources/john-f-kennedy-speeches/american-university-19630610
Preserved university edition: https://www.presidency.ucsb.edu/documents/commencement-address-american-university-washington
Original recording file and retained file description: https://upload.wikimedia.org/wikipedia/commons/b/b5/Jfk_American_University_4654_06-10-63.ogg ; https://commons.wikimedia.org/wiki/File:Jfk_American_University_4654_06-10-63.ogg
Original source/audio hashes, continuous window, source-bound transcript, technical checks and retained ASR disagreements are recorded in the local preparation evidence. No modern notes, images, music, rights of other speakers or uninspected remainder are granted. Local source-only import; regional/source-specific publication pending. No whole-source/public-release approval. Original authored drafts and independent-check constraints remain unchanged.
